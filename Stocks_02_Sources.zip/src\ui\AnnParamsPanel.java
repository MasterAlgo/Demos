package ui;

import globals.AppConfig;
import globals.Globals;
import utilities.PersistenceUtility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class AnnParamsPanel extends JPanel {

    private JTextField tokenDictSizeField;
    private JTextField annSizeField;
    private JTextField allocatedCapacityField;
    private JProgressBar datasetProgressBar;
    private JProgressBar compactingProgressBar;
    private DistributionGraphPanel distributionGraphPanel;

    public AnnParamsPanel() {
        Globals.annParamsPanel = this; // Register global reference

        setBorder(BorderFactory.createTitledBorder("ANN Params"));
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 5, 2, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;

        // --- Configuration Section ---

        // Training Window Size
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        add(new JLabel("Training Window:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField trainingWindowField = new JTextField(String.valueOf(AppConfig.TRAINING_WINDOW_SIZE), 15);
        addAutoSaveListener(trainingWindowField, "TRAINING_WINDOW_SIZE");
        add(trainingWindowField, gbc);
        row++;

        // Prediction Window Size
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Prediction Window:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField predictionWindowField = new JTextField(String.valueOf(AppConfig.PREDICTION_WINDOW_SIZE), 15);
        addAutoSaveListener(predictionWindowField, "PREDICTION_WINDOW_SIZE");
        add(predictionWindowField, gbc);
        row++;

        // Min Actual Tokens (was L1 Cache Size)
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Min Actual Tokens:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField minActualTokensField = new JTextField(String.valueOf(AppConfig.MIN_ACTUAL_TOKENS), 15);
        addAutoSaveListener(minActualTokensField, "MIN_ACTUAL_TOKENS");
        add(minActualTokensField, gbc);
        row++;

        // Compacting Rate %
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Compacting Rate %:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField compactingRateField = new JTextField(String.valueOf((int)(Globals.REMOVE_THRESHOLD_PERCENT * 100)), 15);
        compactingRateField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String value = compactingRateField.getText();
                if (value != null && !value.trim().isEmpty()) {
                    try {
                        float rate = Float.parseFloat(value.trim());
                        Globals.REMOVE_THRESHOLD_PERCENT = rate / 100.0f;
                        // Optionally save to properties if needed
                    } catch (NumberFormatException ignored) {}
                }
            }
        });
        add(compactingRateField, gbc);
        row++;

        // Token Dict Size (was L2 Cache Size)
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Token Dict Size:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        tokenDictSizeField = new JTextField("0", 15);
        tokenDictSizeField.setEditable(false); // Display only
        add(tokenDictSizeField, gbc);
        row++;

        // ANN Size
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("ANN Size:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        annSizeField = new JTextField("0", 15);
        annSizeField.setEditable(false); // Display only
        add(annSizeField, gbc);
        row++;

        // Max Patterns (Trigger)
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Max Patterns (Trigger):"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField maxPatternsField = new JTextField(String.valueOf(AppConfig.PATTERNS_CONTAINER_SIZE), 15);
        addAutoSaveListener(maxPatternsField, "Patterns_Container_Size");
        // Add listener to update allocated capacity
        maxPatternsField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                updateAllocatedCapacity(maxPatternsField.getText());
            }
        });
        add(maxPatternsField, gbc);
        row++;

        // Allocated Capacity
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Allocated Capacity:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        allocatedCapacityField = new JTextField("0", 15);
        allocatedCapacityField.setEditable(false);
        allocatedCapacityField.setBackground(new Color(240, 240, 240)); // Light gray to indicate read-only
        add(allocatedCapacityField, gbc);
        
        // Initialize allocated capacity
        updateAllocatedCapacity(String.valueOf(AppConfig.PATTERNS_CONTAINER_SIZE));
        
        row++;

        // --- Progress Section ---
        gbc.insets = new Insets(10, 5, 2, 5);

        // Dataset Progress
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Dataset Processing:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        datasetProgressBar = new JProgressBar(0, 100);
        datasetProgressBar.setStringPainted(true);
        add(datasetProgressBar, gbc);
        row++;

        // Compacting Progress
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Compacting:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        compactingProgressBar = new JProgressBar(0, 100);
        compactingProgressBar.setStringPainted(true);
        compactingProgressBar.setString("Idle");
        add(compactingProgressBar, gbc);
        row++;

        // --- Distribution Graph Section ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.weighty = 0.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(new JLabel("Keys Distribution:"), gbc);
        row++;

        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0; // Give vertical space to the graph
        gbc.fill = GridBagConstraints.BOTH;
        distributionGraphPanel = new DistributionGraphPanel();
        add(distributionGraphPanel, gbc);
    }

    public void updateDatasetProgress(int percent) {
        if (datasetProgressBar != null) {
            SwingUtilities.invokeLater(() -> datasetProgressBar.setValue(percent));
        }
    }

    public void updateCompactingProgress(String text, int percent) {
        if (compactingProgressBar != null) {
            SwingUtilities.invokeLater(() -> {
                compactingProgressBar.setString(text);
                compactingProgressBar.setValue(percent);
                if (text.startsWith("Dumping")) {
                    compactingProgressBar.setForeground(Color.RED);
                } else if (text.startsWith("Populating")) {
                    compactingProgressBar.setForeground(Color.GREEN);
                } else {
                    compactingProgressBar.setForeground(UIManager.getColor("ProgressBar.foreground"));
                }
            });
        }
    }

    public void updateTokenDictSize(int size) {
        if (tokenDictSizeField != null) {
            SwingUtilities.invokeLater(() -> tokenDictSizeField.setText(String.format("%,d", size)));
        }
    }

    public void updateAnnSize(long size) {
        if (annSizeField != null) {
            SwingUtilities.invokeLater(() -> annSizeField.setText(String.format("%,d", size)));
        }
    }

    public void updateDistributionGraph(int[] distribution) {
        updateDistributionGraph(distribution, -1);
    }

    public void updateDistributionGraph(int[] distribution, int countAboveThreshold) {
        if (distributionGraphPanel != null) {
            SwingUtilities.invokeLater(() -> distributionGraphPanel.addDistribution(distribution, countAboveThreshold));
        }
    }

    private void updateAllocatedCapacity(String maxPatternsStr) {
        try {
            int maxPatterns = Integer.parseInt(maxPatternsStr.trim());
            // Logic from FlatHashMap: capacity = tableSizeFor((int) (initialCapacity / LOAD_FACTOR) + 1);
            // LOAD_FACTOR is 0.7f
            int capacity = tableSizeFor((int) (maxPatterns / 0.7f) + 1);
            allocatedCapacityField.setText(String.format("%,d", capacity));
        } catch (NumberFormatException e) {
            allocatedCapacityField.setText("Invalid");
        }
    }

    private static int tableSizeFor(int cap) {
        int n = cap - 1;
        n |= n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        return (n < 0) ? 1 : (n >= 1 << 30) ? 1 << 30 : n + 1;
    }

    private void addAutoSaveListener(JTextField textField, String propertyKey) {
        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String value = textField.getText();
                if (value != null && !value.trim().isEmpty()) {
                    PersistenceUtility.setPropertyAndSave(propertyKey, value.trim());
                    
                    // Update static fields in AppConfig if applicable
                    if ("TRAINING_WINDOW_SIZE".equals(propertyKey)) {
                        try {
                            AppConfig.TRAINING_WINDOW_SIZE = Integer.parseInt(value.trim());
                        } catch (NumberFormatException ignored) {}
                    } else if ("PREDICTION_WINDOW_SIZE".equals(propertyKey)) {
                        try {
                            AppConfig.PREDICTION_WINDOW_SIZE = Integer.parseInt(value.trim());
                        } catch (NumberFormatException ignored) {}
                    } else if ("MIN_ACTUAL_TOKENS".equals(propertyKey)) {
                        try {
                            AppConfig.MIN_ACTUAL_TOKENS = Integer.parseInt(value.trim());
                        } catch (NumberFormatException ignored) {}
                    } else if ("Patterns_Container_Size".equals(propertyKey)) {
                        try {
                            AppConfig.PATTERNS_CONTAINER_SIZE = Integer.parseInt(value.trim());
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        });
    }
}
