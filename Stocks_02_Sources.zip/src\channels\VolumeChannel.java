package channels;

import channels.helpers.DiscretizedWeightedBinner;
import globals.Globals;
import java.util.List;

public class VolumeChannel extends Channel {

    private int gradeCount;
    private int referencePoint; // For alignment only
    
    private int binnerStep;
    private boolean binnerWeightByVolume;
    private DiscretizedWeightedBinner binner;
    private boolean isInitialized = false;

    public VolumeChannel() {
        super("Volume");
        refreshParameters();
    }

    @Override
    public void refreshParameters() {
        this.gradeCount = getConfigInt("Volume_gradeCount", 10);
        this.referencePoint = getConfigInt("OHLC_referencePoint", -1);
        
        this.binnerStep = getConfigInt("Volume_binnerStep", 1000);
        this.binnerWeightByVolume = Boolean.parseBoolean(getConfigString("Volume_binnerWeightByVolume", "true"));
        
        // Force re-initialization of the binner on next usage
        this.isInitialized = false;
    }

    @Override
    public boolean populateWindow(DailyData currentDay, int minuteIndex, int windowSize, int[] targetArray) {
        // Lazy Initialization of Global Stats (this still needs to be done once or after refresh)
        if (!isInitialized) {
            calculateGlobalStats(Globals.allData);
            isInitialized = true;
        }

        // Alignment Check (Must match PriceChannel logic)
        if (minuteIndex + referencePoint < 0) return false;
        if (minuteIndex + windowSize > currentDay.volumes.size()) return false;

        // Populate Target Array
        for (int i = 0; i < windowSize; i++) {
            int currentMinute = minuteIndex + i;
            
            // Check if the current minute data is missing
            if (currentDay.isMissing.get(currentMinute)) {
                targetArray[i] = Globals.MISSING_TOKEN;
                continue;
            }
            
            int vol = currentDay.volumes.get(currentMinute);
            if (vol < 0) vol = 0;

            int grade = binner.binIndex(vol);
            targetArray[i] = grade;
        }

        return true;
    }

    private void calculateGlobalStats(List<DailyData> allData) {
        binner = new DiscretizedWeightedBinner(gradeCount, binnerStep);

        for (DailyData day : allData) {
            for (int i = 0; i < day.volumes.size(); i++) {
                // Skip missing data during training
                if (day.isMissing.get(i)) continue;
                
                int vol = day.volumes.get(i);
                if (vol < 0) vol = 0;
                binner.add(vol, binnerWeightByVolume);
            }
        }
    }
}
