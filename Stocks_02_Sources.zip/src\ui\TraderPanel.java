package ui;

import globals.Globals;
import tests.ChannelsTestFrame;
import javax.swing.*;
import java.awt.*;

public class TraderPanel extends JPanel {

    private final JButton startButton;
    private final JButton stopButton;
    private final JCheckBox pauseCheckBox;
    private final JCheckBox pauseOnTradeCheckBox; // New Checkbox
    private final JButton testButton; 
    private final JTextArea logArea;

    public TraderPanel() {
        super(new BorderLayout());

        // --- Top Control Panel ---
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        stopButton.setEnabled(false);
        pauseCheckBox = new JCheckBox("Pause");
        
        // New "Pause on Trade" Checkbox
        pauseOnTradeCheckBox = new JCheckBox("Pause on Trade");
        pauseOnTradeCheckBox.addActionListener(e -> {
            Globals.PAUSE_ON_TRADE = pauseOnTradeCheckBox.isSelected();
        });
        
        testButton = new JButton("Testing Grounds");
        testButton.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> new ChannelsTestFrame().setVisible(true));
        });

        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        controlPanel.add(pauseCheckBox);
        controlPanel.add(pauseOnTradeCheckBox); // Add to panel
        controlPanel.add(Box.createHorizontalStrut(20)); // Spacer
        controlPanel.add(testButton);

        add(controlPanel, BorderLayout.NORTH);

        // --- Center Log Panel ---
        logArea = new JTextArea(20, 50);
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Trade Outcome"));
        
        add(scrollPane, BorderLayout.CENTER);
        
        // Wire up Globals
        Globals.logArea = this.logArea;
    }

    public JButton getStartButton() {
        return startButton;
    }

    public JButton getStopButton() {
        return stopButton;
    }

    public JCheckBox getPauseCheckBox() {
        return pauseCheckBox;
    }
    
    public JCheckBox getPauseOnTradeCheckBox() {
        return pauseOnTradeCheckBox;
    }

    public void appendLog(String message) {
        SwingUtilities.invokeLater(() -> {
            logArea.append(message + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        });
    }
}
