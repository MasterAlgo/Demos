package optimizer;

import java.util.List;
import java.util.Map;

public class OptimizationResult {
    public final int runNumber;
    public final Map<String, String> parameters;
    public final double sharpeRatio;
    public final double maxDrawdown;
    public final double profitFactor;
    public final int tradeCount;
    public final double totalProfit;

    public OptimizationResult(int runNumber, Map<String, String> parameters, List<TradeInfo> trades) {
        this.runNumber = runNumber;
        this.parameters = parameters;
        this.tradeCount = trades.size();
        
        if (trades.isEmpty()) {
            this.sharpeRatio = 0;
            this.maxDrawdown = 0;
            this.profitFactor = 0;
            this.totalProfit = 0;
            return;
        }

        this.totalProfit = trades.get(trades.size() - 1).accumulatedOutcome;
        
        // --- Calculate Metrics ---
        double avgReturn = calculateAverageReturn(trades);
        double stdDev = calculateStandardDeviation(trades, avgReturn);
        this.sharpeRatio = (stdDev == 0) ? 0 : (avgReturn / stdDev) * Math.sqrt(252); // Annualized
        
        this.maxDrawdown = calculateMaxDrawdown(trades);
        this.profitFactor = calculateProfitFactor(trades);
    }

    private double calculateAverageReturn(List<TradeInfo> trades) {
        if (trades.isEmpty()) return 0;
        return trades.stream().mapToDouble(t -> t.actualOutcome).average().orElse(0);
    }

    private double calculateStandardDeviation(List<TradeInfo> trades, double mean) {
        if (trades.size() < 2) return 0;
        double sumOfSquares = trades.stream().mapToDouble(t -> Math.pow(t.actualOutcome - mean, 2)).sum();
        return Math.sqrt(sumOfSquares / (trades.size() - 1));
    }

    private double calculateMaxDrawdown(List<TradeInfo> trades) {
        double maxDrawdown = 0;
        double peak = Double.NEGATIVE_INFINITY;
        for (TradeInfo trade : trades) {
            if (trade.accumulatedOutcome > peak) {
                peak = trade.accumulatedOutcome;
            }
            double drawdown = peak - trade.accumulatedOutcome;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }
        return maxDrawdown;
    }

    private double calculateProfitFactor(List<TradeInfo> trades) {
        double grossProfit = trades.stream().filter(t -> t.actualOutcome > 0).mapToDouble(t -> t.actualOutcome).sum();
        double grossLoss = Math.abs(trades.stream().filter(t -> t.actualOutcome < 0).mapToDouble(t -> t.actualOutcome).sum());
        return (grossLoss == 0) ? Double.POSITIVE_INFINITY : grossProfit / grossLoss;
    }
    
    public Object[] toTableRow() {
        return new Object[]{
            runNumber,
            parameters.toString(),
            String.format("%.2f", sharpeRatio),
            String.format("%.2f", maxDrawdown),
            String.format("%.2f", profitFactor)
        };
    }
}
