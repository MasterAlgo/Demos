package ui;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import globals.Globals;

public class MemoryPanel extends JPanel implements Runnable {

    private final List<Long> usedHistory = new ArrayList<>();
    private final List<Long> totalHistory = new ArrayList<>();
    private final List<Long> maxHistory = new ArrayList<>();
    private final TitledBorder border;
    private static final long MB = 1024 * 1024;

    public MemoryPanel() {
        this.setPreferredSize(new Dimension(0, 120));
        this.border = BorderFactory.createTitledBorder("Memory Usage");
        this.border.setTitleColor(Color.BLACK); // Changed to BLACK for visibility on default background
        this.setBorder(border);
    }

    public void start() {
        Thread memoryThread = new Thread(this);
        memoryThread.setDaemon(true);
        memoryThread.setName("Memory-Telemetry-Thread");
        memoryThread.start();
    }

    private long[] getTelemetry() {
        Runtime r = Runtime.getRuntime();
        long free = r.freeMemory();
        long total = r.totalMemory();
        long max = r.maxMemory();
        return new long[]{free, total, max};
    }

    @Override
    public void run() {
        while (true) {
            try {
                long[] telemetryData = getTelemetry();
                SwingUtilities.invokeLater(() -> updateMemory(telemetryData));
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private void updateMemory(long[] memoryData) {
        long free = memoryData[0];
        long total = memoryData[1];
        long max = memoryData[2];
        long used = total - free;
        
        usedHistory.add(used);
        totalHistory.add(total);
        maxHistory.add(max);

        // Prune history to fit the panel width
        while (getWidth() > 0 && usedHistory.size() > getWidth()) {
            usedHistory.remove(0);
            totalHistory.remove(0);
            maxHistory.remove(0);
        }

        border.setTitle(String.format("Used: %,d MB / Allocated: %,d MB / Max: %,d MB", used / MB, total / MB, max / MB));
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Enable anti-aliasing for smoother lines
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Clear background
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, getWidth(), getHeight());

        if (usedHistory.isEmpty()) {
            return;
        }

        long maxMem = maxHistory.get(maxHistory.size() - 1);
        if (maxMem == 0) return;

        Insets insets = getInsets();
        int drawableWidth = getWidth() - insets.left - insets.right;
        int drawableHeight = getHeight() - insets.top - insets.bottom;
        int drawableY = insets.top;

        // Draw Memory Bars (Background)
        for (int i = 0; i < usedHistory.size(); i++) {
            long totalVal = totalHistory.get(i);
            long usedVal = usedHistory.get(i);

            int x = insets.left + i;
            if (x >= getWidth()) break;

            // Draw Total Memory
            int totalHeight = (int) (drawableHeight * ((double) totalVal / maxMem));
            int totalY = drawableY + drawableHeight - totalHeight;
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.drawLine(x, totalY, x, drawableY + drawableHeight);

            // Draw Used Memory
            int usedHeight = (int) (drawableHeight * ((double) usedVal / maxMem));
            int usedY = drawableY + drawableHeight - usedHeight;
            g2d.setColor(Color.CYAN);
            g2d.drawLine(x, usedY, x, drawableY + drawableHeight);
        }
    }
}
