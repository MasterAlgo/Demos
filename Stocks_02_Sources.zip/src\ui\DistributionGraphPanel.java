package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class DistributionGraphPanel extends JPanel {

    private final List<int[]> history = new ArrayList<>();
    // Colors for different history lines. 
    // Latest will be distinct (e.g., Red or Black), older ones in fading colors or a cycle.
    private static final Color[] COLORS = {
        Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.ORANGE, Color.CYAN, Color.PINK
    };
    
    // Configurable settings
    private int startIndex = 2;
    private int endIndex = 99;
    private boolean logScale = true;
    private boolean showValues = false;
    
    private int countAboveThreshold = -1;
    
    private DistributionDetailFrame detailFrame;

    public DistributionGraphPanel() {
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createLineBorder(Color.GRAY));
        setPreferredSize(new Dimension(400, 200)); // Default size, can be resized by layout
        
        // Add mouse listener to open detail frame
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openDetailFrame();
            }
        });
    }
    
    public void setRange(int start, int end) {
        this.startIndex = start;
        this.endIndex = end;
        repaint();
    }
    
    public void setLogScale(boolean logScale) {
        this.logScale = logScale;
        repaint();
    }
    
    public void setShowValues(boolean showValues) {
        this.showValues = showValues;
        repaint();
    }

    public void addDistribution(int[] distribution) {
        addDistribution(distribution, -1);
    }

    public void addDistribution(int[] distribution, int countAboveThreshold) {
        // Clone the array to ensure we store a snapshot
        if (distribution != null) {
            int[] clone = distribution.clone();
            history.add(clone);
            this.countAboveThreshold = countAboveThreshold;
            repaint();
            
            // Update detail frame if open
            if (detailFrame != null && detailFrame.isVisible()) {
                detailFrame.updateHistory(history);
            }
        }
    }

    public void clearHistory() {
        history.clear();
        countAboveThreshold = -1;
        repaint();
        if (detailFrame != null) {
            detailFrame.updateHistory(history);
        }
    }
    
    private void openDetailFrame() {
        if (detailFrame == null) {
            detailFrame = new DistributionDetailFrame(history);
        } else {
            detailFrame.updateHistory(history);
        }
        detailFrame.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (history.isEmpty()) {
            g.drawString("No distribution data yet", 10, 20);
            return;
        }

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        int padding = 20;
        int graphW = w - 2 * padding;
        int graphH = h - 2 * padding;

        // Determine max value for scaling
        double maxVal = 0;
        
        for (int[] dist : history) {
            for (int i = startIndex; i <= endIndex && i < dist.length; i++) {
                double val = logScale ? Math.log10(Math.max(1, dist[i])) : dist[i];
                if (val > maxVal) {
                    maxVal = val;
                }
            }
        }

        if (maxVal == 0) maxVal = 1; // Avoid divide by zero

        // Draw all historical lines
        for (int k = 0; k < history.size(); k++) {
            int[] dist = history.get(k);
            boolean isLatest = (k == history.size() - 1);
            
            // Choose color based on index, consistent across repaints
            g2.setColor(COLORS[k % COLORS.length]);
            
            // Set stroke: Thick for latest, thin for history
            if (isLatest) {
                g2.setStroke(new BasicStroke(3.0f)); 
            } else {
                g2.setStroke(new BasicStroke(1.0f));
            }

            // Draw line graph
            int numPoints = endIndex - startIndex + 1;
            if (numPoints < 2) continue;

            int prevX = -1;
            int prevY = -1;

            for (int i = 0; i < numPoints; i++) {
                int dataIndex = startIndex + i;
                if (dataIndex >= dist.length) break;
                
                int val = dist[dataIndex];
                
                // Calculate Y
                int y;
                double plotVal = logScale ? Math.log10(Math.max(1, val)) : val;
                
                if (val <= 0) {
                    y = h - padding; // Baseline
                } else {
                    y = h - padding - (int) (plotVal * graphH / maxVal);
                }
                
                int x = padding + (int) ((long) i * graphW / (numPoints - 1));

                if (prevX != -1) {
                    g2.drawLine(prevX, prevY, x, y);
                }
                
                // Draw value if enabled and it's the latest graph
                if (showValues && isLatest && val > 0) {
                    g2.setFont(new Font("SansSerif", Font.PLAIN, 16)); // Increased font size to 20
                    g2.drawString(String.valueOf(val), x - 5, y - 5);
                }

                prevX = x;
                prevY = y;
            }
        }
        
        // Draw axes
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1.0f));
        g2.drawLine(padding, h - padding, w - padding, h - padding); // X axis
        g2.drawLine(padding, padding, padding, h - padding); // Y axis
        
        // Draw Y-axis labels
        g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
        if (logScale) {
            int numTicks = (int) maxVal;
            for (int i = 0; i <= numTicks; i++) {
                int y = h - padding - (int) (i * graphH / maxVal);
                g2.drawLine(padding - 2, y, padding + 2, y);
                g2.drawString("10^" + i, 2, y + 5);
            }
        } else {
            g2.drawString(String.valueOf((int)maxVal), 2, padding + 10);
        }
        
        g2.drawString("Idx " + startIndex, padding, h - 5);
        g2.drawString("Idx " + endIndex, w - padding - 30, h - 5);
        
        // Draw count above threshold
        if (countAboveThreshold >= 0) {
            g2.setFont(new Font("SansSerif", Font.BOLD, 12));
            g2.setColor(Color.BLACK);
            String text = "Count >= MinPattern: " + countAboveThreshold;
            FontMetrics fm = g2.getFontMetrics();
            int textWidth = fm.stringWidth(text);
            g2.drawString(text, w - padding - textWidth, padding + 15);
        }
    }
}
