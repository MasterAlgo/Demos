package channels;

import globals.Globals;
import java.util.List;

public class MovingAverageChannel extends Channel {

    private String scope;
    private int period;
    private double threshold;

    public MovingAverageChannel() {
        super("Moving Average");
        refreshParameters();
    }

    @Override
    public void refreshParameters() {
        this.scope = getConfigString("MovingAverage_scope", "day");
        this.period = getConfigInt("MovingAverage_period", 25);
        // Threshold is a percentage (e.g., 0.5 means 0.5%)
        String thresholdStr = getConfigString("MovingAverage_threshold", "0.5");
        try {
            this.threshold = Double.parseDouble(thresholdStr);
        } catch (NumberFormatException e) {
            this.threshold = 0.5;
        }
    }

    @Override
    public boolean populateWindow(DailyData currentDay, int minuteIndex, int windowSize, int[] targetArray) {
        // We use Globals.currentDayIndex and Globals.currentMinuteIndex to know where we are in the full history.
        // Note: The 'minuteIndex' passed to this method is the start of the window we are populating.
        // It should match Globals.currentMinuteIndex, but we'll use the passed value for the window loop.
        
        int currentDayIdx = Globals.currentDayIndex;
        
        // Safety check
        if (currentDayIdx < 0 || currentDayIdx >= Globals.allData.size()) {
            return false;
        }

        // Populate Target Array
        for (int i = 0; i < windowSize; i++) {
            int targetMinuteIdx = minuteIndex + i;

            // Check if the current minute data is missing
            if (currentDay.isMissing.get(targetMinuteIdx)) {
                targetArray[i] = Globals.MISSING_TOKEN;
                continue;
            }

            // Get the current price
            float currentPrice = currentDay.closePrices.get(targetMinuteIdx);
            
            // Calculate the Moving Average for this specific point in time
            double maValue = calculateMovingAverage(currentDayIdx, targetMinuteIdx);

            if (maValue == -1) {
                // Not enough history to calculate MA
                targetArray[i] = 0; // "At" (Neutral)
            } else {
                // Quantize the difference
                targetArray[i] = quantize(currentPrice, maValue);
            }
        }

        return true;
    }

    private double calculateMovingAverage(int dayIdx, int minuteIdx) {
        double sum = 0;
        int count = 0;

        if ("day".equalsIgnoreCase(scope)) {
            // Day scope: Average of last 'period' days' CLOSE prices
            // We start from the previous day because the current day is not yet complete/closed
            // (or we could include current day's current price, but typically MA is on closed candles)
            // Let's assume standard MA on daily close prices, so we look at dayIdx - 1, dayIdx - 2, etc.
            
            if (dayIdx < period) {
                return -1; // Not enough history
            }

            for (int k = 1; k <= period; k++) {
                DailyData pastDay = Globals.allData.get(dayIdx - k);
                // Use the last close price of that day
                if (!pastDay.closePrices.isEmpty()) {
                    sum += pastDay.closePrices.get(pastDay.closePrices.size() - 1);
                    count++;
                }
            }
        } else if ("minute".equalsIgnoreCase(scope)) {
            // Minute scope: Average of last 'period' minutes
            // We need to traverse backwards across days if necessary
            
            int d = dayIdx;
            int m = minuteIdx;
            
            while (count < period) {
                // If we run out of minutes in the current day, go to previous day
                if (m < 0) {
                    d--;
                    if (d < 0) return -1; // Not enough history
                    DailyData prevDay = Globals.allData.get(d);
                    m = prevDay.closePrices.size() - 1;
                }
                
                DailyData day = Globals.allData.get(d);
                // Skip missing data? For now, let's just use what's there or skip if missing
                if (!day.isMissing.get(m)) {
                    sum += day.closePrices.get(m);
                    count++;
                }
                
                m--;
            }
        } else if ("hour".equalsIgnoreCase(scope)) {
            // Hour scope: Average of last 'period' hours (60-minute intervals)
            // Similar to minute, but we jump 60 minutes
            
            int d = dayIdx;
            int m = minuteIdx;
            
            while (count < period) {
                if (m < 0) {
                    d--;
                    if (d < 0) return -1;
                    DailyData prevDay = Globals.allData.get(d);
                    m = prevDay.closePrices.size() - 1;
                }
                
                DailyData day = Globals.allData.get(d);
                if (!day.isMissing.get(m)) {
                    sum += day.closePrices.get(m);
                    count++;
                }
                
                m -= 60; // Jump back 1 hour
            }
        }

        return (count == period) ? (sum / count) : -1;
    }

    private int quantize(float currentPrice, double maValue) {
        double diffPercent = ((currentPrice - maValue) / maValue) * 100.0;
        
        // Thresholds: 
        // 0: At (within +/- threshold)
        // 1: Above (> threshold)
        // 2: High Above (> 2 * threshold)
        // -1: Below (< -threshold)
        // -2: Deep Below (< -2 * threshold)

        if (Math.abs(diffPercent) <= threshold) {
            return 0;
        } else if (diffPercent > threshold) {
            return (diffPercent > 2 * threshold) ? 2 : 1;
        } else {
            return (diffPercent < -2 * threshold) ? -2 : -1;
        }
    }
}
