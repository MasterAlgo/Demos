package ui;

import globals.Globals;
import utilities.PersistenceUtility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;

public class TradingParamsPanel extends JPanel {

    public TradingParamsPanel() {
        setBorder(BorderFactory.createTitledBorder("Trading Params"));
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;

        // --- K_FACTOR ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("K Factor (Damping):"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField kFactorField = new JTextField(String.valueOf(Globals.K_FACTOR), 10);
        kFactorField.setToolTipText("Smoothing factor. Higher = more conservative.");
        addAutoSaveListener(kFactorField, "K_FACTOR");
        add(kFactorField, gbc);
        row++;

        // --- MIN_PATTERN_COUNT ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Min Pattern Count:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField minPatternCountField = new JTextField(String.valueOf(Globals.MIN_PATTERN_COUNT), 10);
        minPatternCountField.setToolTipText("Base minimum occurrences for a pattern to be valid.");
        addAutoSaveListener(minPatternCountField, "MIN_PATTERN_COUNT");
        add(minPatternCountField, gbc);
        row++;

        // --- MIN_PATTERN_COUNT_SCALING ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Scaling Method:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        String[] scalingOptions = {"STATIC", "LINEAR", "LOG2", "LN", "LOG10"};
        JComboBox<String> scalingComboBox = new JComboBox<>(scalingOptions);
        scalingComboBox.setSelectedItem(Globals.MIN_PATTERN_COUNT_SCALING);
        scalingComboBox.setToolTipText("Method to scale Min Pattern Count as ANN size grows.");
        scalingComboBox.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                Globals.MIN_PATTERN_COUNT_SCALING = (String) e.getItem();
                PersistenceUtility.setPropertyAndSave("MIN_PATTERN_COUNT_SCALING", Globals.MIN_PATTERN_COUNT_SCALING);
            }
        });
        add(scalingComboBox, gbc);
        row++;

        // --- REFERENCE_ANN_SIZE ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Reference ANN Size:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField refAnnSizeField = new JTextField(String.valueOf(Globals.REFERENCE_ANN_SIZE), 10);
        refAnnSizeField.setToolTipText("The ANN size at which the base Min Pattern Count is most effective.");
        addAutoSaveListener(refAnnSizeField, "REFERENCE_ANN_SIZE");
        add(refAnnSizeField, gbc);
        row++;

        // --- TRADE_THRESHOLD ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weightx = 0.0;
        add(new JLabel("Trade Threshold (cents):"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField tradeThresholdField = new JTextField(String.valueOf(Globals.TRADE_THRESHOLD), 10);
        tradeThresholdField.setToolTipText("Minimum predicted price change to trigger a trade.");
        addAutoSaveListener(tradeThresholdField, "TRADE_THRESHOLD");
        add(tradeThresholdField, gbc);
        row++;

        // --- Extended Logging ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        JCheckBox extendedLoggingCheck = new JCheckBox("Extended Logging (Text)", Globals.EXTENDED_LOGGING);
        extendedLoggingCheck.setToolTipText("Show detailed trade context in the log area.");
        extendedLoggingCheck.addItemListener(e -> {
            Globals.EXTENDED_LOGGING = (e.getStateChange() == ItemEvent.SELECTED);
            PersistenceUtility.setPropertyAndSave("EXTENDED_LOGGING", String.valueOf(Globals.EXTENDED_LOGGING));
        });
        add(extendedLoggingCheck, gbc);
        row++;

        // --- Show Intraday Chart ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        JCheckBox showIntradayChartCheck = new JCheckBox("Show Intraday Chart", Globals.SHOW_INTRADAY_CHART);
        showIntradayChartCheck.setToolTipText("Display the intraday chart for each trade.");
        showIntradayChartCheck.addItemListener(e -> {
            Globals.SHOW_INTRADAY_CHART = (e.getStateChange() == ItemEvent.SELECTED);
            PersistenceUtility.setPropertyAndSave("SHOW_INTRADAY_CHART", String.valueOf(Globals.SHOW_INTRADAY_CHART));
        });
        add(showIntradayChartCheck, gbc);
        row++;

        // --- Show Profit Chart ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        JCheckBox showProfitChartCheck = new JCheckBox("Show Profit Chart", Globals.SHOW_PROFIT_CHART);
        showProfitChartCheck.setToolTipText("Display the accumulated profit chart.");
        showProfitChartCheck.addItemListener(e -> {
            Globals.SHOW_PROFIT_CHART = (e.getStateChange() == ItemEvent.SELECTED);
            PersistenceUtility.setPropertyAndSave("SHOW_PROFIT_CHART", String.valueOf(Globals.SHOW_PROFIT_CHART));
        });
        add(showProfitChartCheck, gbc);
        row++;

        // --- Heuristic Infer Checkbox ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 2;
        JCheckBox heuristicInferCheck = new JCheckBox("Heuristic Infer", Globals.HEURISTIC_ENABLED);
        heuristicInferCheck.setToolTipText("Enable heuristic-based inference instead of classic statistical theory.");
        heuristicInferCheck.addItemListener(e -> {
            Globals.HEURISTIC_ENABLED = (e.getStateChange() == ItemEvent.SELECTED);
            PersistenceUtility.setPropertyAndSave("HEURISTIC_ENABLED", String.valueOf(Globals.HEURISTIC_ENABLED));
        });
        add(heuristicInferCheck, gbc);
        row++;

        // --- SENTIMENT_THRESHOLD ---
        gbc.gridx = 0; gbc.gridy = row;
        gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        add(new JLabel("Sentiment Threshold:"), gbc);
        
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        JTextField sentimentThresholdField = new JTextField(String.valueOf(Globals.SENTIMENT_THRESHOLD), 10);
        sentimentThresholdField.setToolTipText("Minimum sentiment score to trigger a heuristic trade.");
        addAutoSaveListener(sentimentThresholdField, "SENTIMENT_THRESHOLD");
        add(sentimentThresholdField, gbc);
        row++;

        // Spacer to push content to top
        gbc.gridx = 0; gbc.gridy = row;
        gbc.weighty = 1.0;
        add(Box.createVerticalGlue(), gbc);
    }

    private void addAutoSaveListener(JTextField textField, String propertyKey) {
        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                String value = textField.getText();
                if (value != null && !value.trim().isEmpty()) {
                    // Update Globals immediately
                    try {
                        if ("K_FACTOR".equals(propertyKey)) {
                            Globals.K_FACTOR = Integer.parseInt(value.trim());
                        } else if ("MIN_PATTERN_COUNT".equals(propertyKey)) {
                            Globals.MIN_PATTERN_COUNT = Integer.parseInt(value.trim());
                        } else if ("TRADE_THRESHOLD".equals(propertyKey)) {
                            Globals.TRADE_THRESHOLD = Float.parseFloat(value.trim());
                        } else if ("SENTIMENT_THRESHOLD".equals(propertyKey)) {
                            Globals.SENTIMENT_THRESHOLD = Float.parseFloat(value.trim());
                        } else if ("REFERENCE_ANN_SIZE".equals(propertyKey)) {
                            Globals.REFERENCE_ANN_SIZE = Long.parseLong(value.trim());
                        }
                        
                        PersistenceUtility.setPropertyAndSave(propertyKey, value.trim());
                    } catch (NumberFormatException ex) {
                        // Revert to current global value on error
                        if ("K_FACTOR".equals(propertyKey)) {
                            textField.setText(String.valueOf(Globals.K_FACTOR));
                        } else if ("MIN_PATTERN_COUNT".equals(propertyKey)) {
                            textField.setText(String.valueOf(Globals.MIN_PATTERN_COUNT));
                        } else if ("TRADE_THRESHOLD".equals(propertyKey)) {
                            textField.setText(String.valueOf(Globals.TRADE_THRESHOLD));
                        } else if ("SENTIMENT_THRESHOLD".equals(propertyKey)) {
                            textField.setText(String.valueOf(Globals.SENTIMENT_THRESHOLD));
                        } else if ("REFERENCE_ANN_SIZE".equals(propertyKey)) {
                            textField.setText(String.valueOf(Globals.REFERENCE_ANN_SIZE));
                        }
                    }
                }
            }
        });
    }
}
