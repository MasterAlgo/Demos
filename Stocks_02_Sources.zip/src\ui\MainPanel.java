package ui;

import optimizer.OptimizationPanel;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import globals.Globals;

public class MainPanel extends JPanel {

    private final JLabel stateLabel;

    public MainPanel() {
        setLayout(new BorderLayout());

        // 1. Create the Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // --- Tab 1: Data Feeders (Static/Seldom Used) ---
        tabbedPane.addTab("Data Feeders", new FeedersPanel());

        // --- Tab 2: Setup & Config (Dynamic/Daily Use) ---
        JPanel setupConfigPanel = new JPanel(new BorderLayout());
        
        // Center: Configuration Grid
        JPanel configGrid = new JPanel(new GridLayout(1, 3, 10, 10));
        configGrid.add(new ChannelsPanel());
        configGrid.add(new AnnParamsPanel());
        // Replaced placeholder with actual panel
        configGrid.add(new TradingParamsPanel());

        setupConfigPanel.add(configGrid, BorderLayout.CENTER);

        // Bottom: Launch Action
        JPanel launchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton launchButton = new JButton("Launch Trader Window");
        launchButton.setFont(new Font("Arial", Font.BOLD, 16));
        launchButton.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> {
                TraderFrame traderFrame = new TraderFrame();
                traderFrame.setVisible(true);
            });
        });
        launchPanel.add(launchButton);
        setupConfigPanel.add(launchPanel, BorderLayout.SOUTH);

        tabbedPane.addTab("Setup & Config", setupConfigPanel);

        // --- Tab 3: Optimization ---
        tabbedPane.addTab("Optimization", new OptimizationPanel());

        // --- Tab 4: Help / About ---
        tabbedPane.addTab("Help / About", createHelpPanel());

        add(tabbedPane, BorderLayout.CENTER);

        // 2. Global Resource Panel (Bottom)
        JPanel resourcePanel = new JPanel(new BorderLayout());
        resourcePanel.setBorder(BorderFactory.createEtchedBorder());
        
        // Add MemoryPanel
        MemoryPanel memoryPanel = new MemoryPanel();
        resourcePanel.add(memoryPanel, BorderLayout.CENTER);
        memoryPanel.start();

        // Add State info
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        stateLabel = new JLabel("State: " + Globals.STATE);
        infoPanel.add(stateLabel);
        resourcePanel.add(infoPanel, BorderLayout.SOUTH);
        
        add(resourcePanel, BorderLayout.SOUTH);

        // Start State Monitor
        startStateMonitor();
    }

    private JPanel createHelpPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        try {
            File file = new File("DEV_MEMO.md");
            if (file.exists()) {
                String content = new String(Files.readAllBytes(file.toPath()));
                textArea.setText(content);
            } else {
                textArea.setText("DEV_MEMO.md not found.");
            }
        } catch (IOException e) {
            textArea.setText("Error reading DEV_MEMO.md: " + e.getMessage());
        }

        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        return panel;
    }

    private void startStateMonitor() {
        Timer timer = new Timer(500, e -> {
            stateLabel.setText("State: " + Globals.STATE);
        });
        timer.start();
    }
}
