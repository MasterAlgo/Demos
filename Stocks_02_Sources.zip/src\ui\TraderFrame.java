package ui;

import globals.Globals;
import trader.DataController;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TraderFrame extends JFrame {

    private final TraderPanel traderPanel;
    private final DataController dataController;

    public TraderFrame() {
        super("Trader Window");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        traderPanel = new TraderPanel();
        add(traderPanel);
        
        dataController = new DataController(traderPanel);
        
        // Wire up buttons
        traderPanel.getStartButton().addActionListener(e -> {
            traderPanel.getStartButton().setEnabled(false);
            traderPanel.getStopButton().setEnabled(true);
            Globals.STATE = "Processing...";
            dataController.start();
        });

        traderPanel.getStopButton().addActionListener(e -> {
            Globals.STATE = "Stopping...";
            dataController.stop();
            // Button state reset is handled by the engine when it actually stops
        });

        traderPanel.getPauseCheckBox().addActionListener(e -> {
            boolean isPaused = traderPanel.getPauseCheckBox().isSelected();
            dataController.setPaused(isPaused);
            if (isPaused) {
                Globals.STATE = "Paused";
            } else {
                Globals.STATE = "Processing...";
            }
        });

        // Stop engine if window is closed
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dataController.stop();
                Globals.STATE = "Idle";
            }
        });
        
        pack();
        setLocationRelativeTo(null); // Center on screen
    }

    public TraderPanel getTraderPanel() {
        return traderPanel;
    }
}
