package optimizer;

import globals.Globals;
import optimizer.strategies.ChannelGranularityStrategy;
import trader.DataController;
import ui.TraderPanel;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public class OptimizerController {

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean paused = new AtomicBoolean(false);

    private Thread optimizationThread;
    private OptimizationPanel panel;

    // Results storage for a single run
    private final List<TradeInfo> currentTrades = Collections.synchronizedList(new ArrayList<>());
    private final List<OptimizationResult> results = new ArrayList<>();
    private CountDownLatch runLatch;

    private final ChannelGranularityStrategy strategy; // Hardcoded for now

    public OptimizerController() {
        // Register self in Globals
        Globals.optimizerController = this;
        this.strategy = new ChannelGranularityStrategy();
    }

    public void setPanel(OptimizationPanel panel) {
        this.panel = panel;
    }
    
    public boolean isRunning() {
        return running.get();
    }

    public void startOptimization() {
        if (running.get()) return;

        running.set(true);
        paused.set(false);
        results.clear();
        if (panel != null) panel.clearResults();

        optimizationThread = new Thread(this::runOptimizationLoop);
        optimizationThread.start();
    }

    public void stopOptimization() {
        running.set(false);
        if (runLatch != null) runLatch.countDown(); // Release the wait
        if (optimizationThread != null) {
            optimizationThread.interrupt();
        }
    }

    public void pauseOptimization(boolean isPaused) {
        paused.set(isPaused);
    }

    private void runOptimizationLoop() {
        try {
            // --- Generate Combinations from Strategy ---
            List<Map<String, String>> combinations = strategy.generateCombinations();
            int runNumber = 1;

            for (Map<String, String> params : combinations) {
                if (!running.get()) break;

                // --- Pause Logic ---
                while (paused.get()) {
                    Thread.sleep(500);
                    if (!running.get()) return;
                }

                // --- Setup Run ---
                currentTrades.clear();
                runLatch = new CountDownLatch(1);
                final int currentRunNumber = runNumber;
                
                SwingUtilities.invokeLater(() -> {
                    if (panel != null) panel.updateStatus(String.format("Running %d/%d: %s", currentRunNumber, combinations.size(), params));
                });

                // --- Apply Parameters using Strategy ---
                strategy.applyParameters(params);

                // --- Run Simulation ---
                // We need a dummy TraderPanel for DataController, but it won't be shown
                DataController dataController = new DataController(new TraderPanel());
                dataController.start();

                // --- Wait for Completion ---
                runLatch.await(); // Waits for onRunFinished to be called

                if (Thread.interrupted() || !running.get()) {
                    break;
                }

                // --- Collect and Display Results ---
                OptimizationResult result = new OptimizationResult(runNumber, params, new ArrayList<>(currentTrades));
                results.add(result);
                SwingUtilities.invokeLater(() -> {
                    if (panel != null) panel.addResult(result);
                });

                runNumber++;
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Preserve interrupted status
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            running.set(false);
            SwingUtilities.invokeLater(() -> {
                if (panel != null) panel.onOptimizationFinished();
            });
        }
    }

    // --- Callbacks from Engine ---

    public void onTrade(TradeInfo tradeInfo) {
        if (!running.get()) return;
        currentTrades.add(tradeInfo);
    }

    public void onRunFinished(RunSummary summary) {
        if (!running.get()) return;
        if (runLatch != null) {
            runLatch.countDown(); // Signal the optimization loop to continue
        }
    }
}
