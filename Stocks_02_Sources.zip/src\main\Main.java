package main;

import containers.TokenDictionary;
import containers.Tokenizer;
import globals.Globals;
import ui.MainFrame;
import utilities.PersistenceUtility;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PersistenceUtility.loadProperties();
            
            // Initialize Global Containers
            Globals.tokenDictionary = new TokenDictionary();
//            Globals.tokenizer = new Tokenizer_retired();  // retired
            Globals.tokenizer = new Tokenizer();
//            Globals.patternContainer = new PatternContainer_retired();  // retired

            // Initialize channels early to print configuration to console
            new channels.ChannelManager().initialize();

            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}
