package trader;

import channels.ChannelManager;
import containers.PatternEngine;
import containers.TokenDictionary;
import globals.AppConfig;
import channels.DailyData;
import globals.Globals;
import optimizer.RunSummary;
import ui.TraderPanel;
import javax.swing.*;

public class DataController implements Runnable {

    private volatile boolean running = false;
    private volatile boolean paused = false;
    private final TraderPanel panel;
    private final ChannelManager channelManager;

    private int[] futureBuffer;

    public DataController(TraderPanel panel) {
        this.panel = panel;
        this.channelManager = new ChannelManager();
    }

    public void start() {
        running = true;
        paused = false;
        new Thread(this).start();
    }

    public void stop() {
        running = false;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
        // Sync UI checkbox if changed programmatically
        SwingUtilities.invokeLater(() -> panel.getPauseCheckBox().setSelected(paused));
    }

    @Override
    public void run() {
        Globals.STATE = "Initializing...";
        panel.appendLog("Data Controller Started.");

        // Reset TokenDictionary at the start of every run to ensure a clean slate
        Globals.tokenDictionary = new TokenDictionary();

        if (Globals.allData == null || Globals.allData.isEmpty()) {
            panel.appendLog("ERROR: No data loaded. Stopping engine.");
            running = false;
            Globals.STATE = "Error: No Data";
        } else {
            channelManager.initialize();
            panel.appendLog("Initialized " + channelManager.getActiveChannels().size() + " active channels.");
            
            // Initialize both tokenizers, though we'll only use one.
//            Globals.tokenizer.initialize();  // retired
            Globals.tokenizer.initialize();
            panel.appendLog("Tokenizer initialized.");
            
//            Globals.patternContainer.initialize();                     // retired
//            panel.appendLog("PatternEngine initialized.");

            Globals.patternEngine = new PatternEngine();
            Globals.patternEngine.initialize();
            panel.appendLog("PatternEngine initialized.");
            
            Globals.inferenceEngine = new InferenceEngine();
            panel.appendLog("InferenceEngine initialized.");
            
            // Reset simulation statistics at the start of the run
            Globals.inferenceEngine.resetSimulation();
        }

        int trainingWindow = AppConfig.TRAINING_WINDOW_SIZE;
        int predictionWindow = AppConfig.PREDICTION_WINDOW_SIZE;
        
        this.futureBuffer = new int[predictionWindow];

        int totalDays = Globals.allData != null ? Globals.allData.size() : 0;

        Globals.STATE = "Processing...";

        for (int dayIndex = 0; running && dayIndex < totalDays; dayIndex++) {
            DailyData currentDay = Globals.allData.get(dayIndex);
            int daySize = currentDay.closePrices.size(); 

            // panel.appendLog("Processing Day: " + currentDay.date); // Too much logging
            
            // Update UI Progress
            if (Globals.annParamsPanel != null) {
                int progress = (int) (((double) dayIndex / totalDays) * 100);
                Globals.annParamsPanel.updateDatasetProgress(progress);
                Globals.annParamsPanel.updateTokenDictSize(Globals.tokenDictionary.getSize());
                if (Globals.patternEngine != null) {
                    long annSize = Globals.patternEngine.size();
                    Globals.ANN_SIZE = annSize;
                    Globals.annParamsPanel.updateAnnSize(annSize);
                }
            } else {
                // panel.appendLog("Warning: AnnParamsPanel is null"); // Debug
            }

            // Modified loop condition to ensure enough data for both training and prediction windows
            for (int minuteIndex = 0; minuteIndex < daySize - (trainingWindow + predictionWindow); minuteIndex++) {
                if (!running) break;
                
                // Check for external pause request (e.g., from InferenceEngine trade)
                if (Globals.REQUEST_PAUSE) {
                    setPaused(true);
                    Globals.REQUEST_PAUSE = false; // Reset flag
                }

                while (paused && running) {
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        running = false;
                    }
                }
                if (!running) break;

                // Update global context BEFORE calling getCombinedMatrix
                Globals.currentDayIndex = dayIndex;
                Globals.currentMinuteIndex = minuteIndex;
                if(Globals.startGlobalPrice   < 0) {
                    Globals.startGlobalPrice   = currentDay.closePrices.get(0); // Initialize of startGlobalPrice
                }

                int[][] matrix = channelManager.getCombinedMatrix(Globals.allData, dayIndex, minuteIndex);

                // With the new loop condition, matrix should never be null here if data is valid
                // However, keeping this check for robustness, or it can be removed if confident.
                if (matrix == null) {
                    continue;
                }

                // Reset only the prediction buffers for the new minute
                Globals.inferenceEngine.resetPrediction();

                int basePriceIndex = minuteIndex + trainingWindow - 1;
                
                // This check is now redundant due to the modified loop condition, but keeping it for now.
                if (basePriceIndex + predictionWindow < daySize) {
                    float basePrice = currentDay.closePrices.get(basePriceIndex);
                    
                    // --- Missing Data Check ---
                    if (basePrice <= 0) {
                        continue; // Skip if base price is invalid/missing
                    }
                    
                    boolean hasMissingFutureData = false;
                    for (int i = 0; i < predictionWindow; i++) {
                        int futureIndex = basePriceIndex + 1 + i;
                        float futurePrice = currentDay.closePrices.get(futureIndex);
                        
                        if (futurePrice <= 0) {
                            hasMissingFutureData = true;
                            break;
                        }
                        
                        this.futureBuffer[i] = (int) ((futurePrice - basePrice) * 100.0f);
                    }
                    
                    if (hasMissingFutureData) {
                        continue; // Skip the entire window if any future data point is missing
                    }
                    
                    // Use the new Tokenizer
                    Globals.tokenizer.tokenize(matrix, this.futureBuffer);
                    
                    float[] prediction = Globals.inferenceEngine.finalizePrediction();
                    
                } else {
                    continue; 
                }

            } 
        } 

        panel.appendLog("Data Controller Finished Processing.");
        
        if (Globals.annParamsPanel != null) {
            Globals.annParamsPanel.updateDatasetProgress(100);
            Globals.annParamsPanel.updateTokenDictSize(Globals.tokenDictionary.getSize());
            if (Globals.patternEngine != null) {
                long annSize = Globals.patternEngine.size();
                Globals.ANN_SIZE = annSize;
                Globals.annParamsPanel.updateAnnSize(annSize);
            }
            // Trigger final distribution update
            if (Globals.patternEngine != null) {
                Globals.patternEngine.forceUpdateDistribution();
            }
        }
        
        if (running) {
            Globals.STATE = "Complete";
            running = false;
        } else {
            Globals.STATE = "Idle";
        }
        
        // Notify Optimizer
        if (Globals.optimizerController != null && Globals.optimizerController.isRunning()) {
            Globals.optimizerController.onRunFinished(new RunSummary(
                Globals.ANN_SIZE,
                Globals.tokenDictionary != null ? Globals.tokenDictionary.getSize() : 0
            ));
        }
        
        SwingUtilities.invokeLater(() -> {
            panel.getStartButton().setEnabled(true);
            panel.getStopButton().setEnabled(false);
            panel.getPauseCheckBox().setSelected(false);
        });
    }
}
