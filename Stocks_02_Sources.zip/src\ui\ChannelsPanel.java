package ui;

import globals.AppConfig;
import utilities.PersistenceUtility;

import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChannelsPanel extends JPanel {

    private final JTree tree;
    private final DefaultTreeModel treeModel;

    public ChannelsPanel() {
        super(new BorderLayout());

        // 1. Create the root node and build the tree structure
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Channels");
        buildChannelTree(root);

        // 2. Create the tree and model
        treeModel = new DefaultTreeModel(root);
        tree = new JTree(treeModel);
        tree.setEditable(true);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setShowsRootHandles(true);

        // 3. Set custom renderer and editor
        ChannelTreeCellRenderer renderer = new ChannelTreeCellRenderer();
        tree.setCellRenderer(renderer);
        tree.setCellEditor(new ChannelTreeCellEditor(tree, renderer));

        // 4. Add to panel
        JScrollPane scrollPane = new JScrollPane(tree);
        add(scrollPane, BorderLayout.CENTER);

        // 5. Expand all nodes
        expandAllNodes(tree, 0, tree.getRowCount());
    }

    private void expandAllNodes(JTree tree, int startingIndex, int rowCount) {
        for (int i = startingIndex; i < rowCount; ++i) {
            tree.expandRow(i);
        }

        if (tree.getRowCount() != rowCount) {
            expandAllNodes(tree, rowCount, tree.getRowCount());
        }
    }

    private void buildChannelTree(DefaultMutableTreeNode root) {
        // For now, we hardcode the available channels. This could come from a registry later.
        String[] availableChannels = {"Open", "High", "Low", "Close", "Volume", "Hour of Day", "Moving Average"};

        for (String channelName : availableChannels) {
            // Create the main channel node
            ChannelNode channelNode = new ChannelNode(channelName);
            root.add(channelNode);

            // Find parameters for this channel
            List<String> paramKeys = findParametersForChannel(channelName);
            for (String paramKey : paramKeys) {
                List<String> options = AppConfig.parametersMap.get(paramKey);
                if (options != null && !options.isEmpty()) {
                    ParameterNode paramNode = new ParameterNode(paramKey, options);
                    channelNode.add(paramNode);
                }
            }
        }
    }

    private List<String> findParametersForChannel(String channelName) {
        List<String> keys = new ArrayList<>();
        // Check for OHLC global params
        if ("Open".equals(channelName) || "High".equals(channelName) || "Low".equals(channelName) || "Close".equals(channelName)) {
            for (String key : AppConfig.parametersMap.keySet()) {
                if (key.startsWith("OHLC_")) {
                    keys.add(key);
                }
            }
        }
        
        // Check for channel-specific params
        // We remove spaces from the channel name to match property keys (e.g., "Hour of Day" -> "HourOfDay_")
        String normalizedChannelName = channelName.replace(" ", "");
        for (String key : AppConfig.parametersMap.keySet()) {
            // Use a case-insensitive check to find the matching parameter key
            if (key.toLowerCase().startsWith(normalizedChannelName.toLowerCase() + "_")) {
                keys.add(key);
            }
        }
        return keys;
    }
}

// --- Helper Classes for Tree Nodes and Rendering ---

class ChannelNode extends DefaultMutableTreeNode {
    boolean isSelected;

    public ChannelNode(String name) {
        super(name);
        this.isSelected = "ON".equalsIgnoreCase(AppConfig.channelProperties.getProperty(name, "OFF"));
    }

    public String getName() {
        return (String) getUserObject();
    }
}

class ParameterNode extends DefaultMutableTreeNode {
    List<String> options;
    String selectedOption;

    public ParameterNode(String name, List<String> options) {
        super(name);
        this.options = options;
        this.selectedOption = AppConfig.channelProperties.getProperty(name, options.get(0));
    }

    public String getName() {
        return (String) getUserObject();
    }
}

class ChannelTreeCellRenderer extends DefaultTreeCellRenderer {
    private final JCheckBox channelRenderer = new JCheckBox();
    private final JComboBox<String> parameterRenderer = new JComboBox<>();
    private final JLabel textRenderer = new JLabel();

    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

        if (value instanceof ChannelNode) {
            ChannelNode node = (ChannelNode) value;
            channelRenderer.setText(node.getName());
            channelRenderer.setSelected(node.isSelected);
            
            // Highlight background if selected
            if (node.isSelected) {
                channelRenderer.setBackground(new Color(200, 255, 200)); // Light Green
                channelRenderer.setOpaque(true);
            } else {
                channelRenderer.setBackground(UIManager.getColor("Tree.textBackground"));
                channelRenderer.setOpaque(false);
            }
            
            return channelRenderer;
        } else if (value instanceof ParameterNode) {
            ParameterNode node = (ParameterNode) value;
            parameterRenderer.removeAllItems();
            for (String item : node.options) {
                parameterRenderer.addItem(item);
            }
            parameterRenderer.setSelectedItem(node.selectedOption);
            // Add a label to show the parameter name
            JPanel panel = new JPanel(new BorderLayout());
            panel.add(new JLabel(node.getName() + ": "), BorderLayout.WEST);
            panel.add(parameterRenderer, BorderLayout.CENTER);
            return panel;
        } else {
            textRenderer.setText(value.toString());
            return textRenderer;
        }
    }
}

class ChannelTreeCellEditor extends DefaultCellEditor {
    private JComboBox<String> comboBox;
    private JCheckBox checkBox;
    private Object currentNode;

    public ChannelTreeCellEditor(JTree tree, DefaultTreeCellRenderer renderer) {
        super(new JCheckBox()); // Dummy editor
    }

    @Override
    public Component getTreeCellEditorComponent(JTree tree, Object value, boolean isSelected, boolean expanded, boolean leaf, int row) {
        currentNode = value;
        if (value instanceof ChannelNode) {
            ChannelNode node = (ChannelNode) value;
            checkBox = new JCheckBox(node.getName(), node.isSelected);
            
            // Match the background color in the editor
            if (node.isSelected) {
                checkBox.setBackground(new Color(200, 255, 200)); // Light Green
                checkBox.setOpaque(true);
            } else {
                checkBox.setBackground(UIManager.getColor("Tree.textBackground"));
                checkBox.setOpaque(false);
            }

            checkBox.addActionListener(e -> {
                node.isSelected = checkBox.isSelected();
                PersistenceUtility.saveChannelProperty(node.getName(), node.isSelected ? "ON" : "OFF");
                stopCellEditing();
                tree.repaint(); // Force repaint to update background color immediately
            });
            return checkBox;
        } else if (value instanceof ParameterNode) {
            ParameterNode node = (ParameterNode) value;
            comboBox = new JComboBox<>(node.options.toArray(new String[0]));
            comboBox.setSelectedItem(node.selectedOption);
            comboBox.addActionListener(e -> {
                node.selectedOption = (String) comboBox.getSelectedItem();
                PersistenceUtility.saveChannelProperty(node.getName(), node.selectedOption);
                stopCellEditing();
            });
            return comboBox;
        }
        return super.getTreeCellEditorComponent(tree, value, isSelected, expanded, leaf, row);
    }

    @Override
    public Object getCellEditorValue() {
        if (currentNode instanceof ChannelNode) {
            return ((ChannelNode) currentNode).getName();
        } else if (currentNode instanceof ParameterNode) {
            return ((ParameterNode) currentNode).getName();
        }
        return super.getCellEditorValue();
    }
}
