package containers;

import globals.AppConfig;
import utilities.Murmur3;
import java.util.HashMap;
import java.util.Map;

public class PatternEngine {

    // Configuration to switch between implementations
    private static final boolean USE_FLAT_MAP = true;
    
    // Initial capacity for the FlatHashMap to avoid resizing overhead.
    // Now configurable via AppConfig.
    // private static final int INITIAL_CAPACITY = 150_000_000;
    
    // A constant seed for the secondary hash to ensure independence.
    private static final long SIGNATURE_SEED = 0x9e3779b97f4a7c15L;

    private Map<Long, int[]> standardMap;
    private FlatHashMap flatMap;
    
    private boolean isInitialized = false;

    public void initialize() {
        if (isInitialized) return;
        
        int capacity = AppConfig.PATTERNS_CONTAINER_SIZE;
        
        if (USE_FLAT_MAP) {
            this.flatMap = new FlatHashMap(capacity);
        } else {
            // Using a HashMap for O(1) average time complexity.
            // Key: 64-bit Murmur3 hash of the pattern.
            // Value: int[] payload (accumulated history).
            this.standardMap = new HashMap<>(capacity);
        }
        
        this.isInitialized = true;
    }

    /**
     * Retrieves the history for a given pattern.
     * @param pattern The input pattern.
     * @return The history payload if found, null otherwise.
     */
    public int[] get(int[] pattern) {
        if (!isInitialized) return null;
        
        if (USE_FLAT_MAP) {
            long key = Murmur3.hash64(pattern, 0);
            long signature = Murmur3.hash64(pattern, SIGNATURE_SEED);
            return flatMap.get(key, signature);
        } else {
            long key = Murmur3.hash64(pattern);
            return standardMap.get(key);
        }
    }

    /**
     * Updates the history for a pattern with new future data.
     * If the pattern does not exist, it is created.
     * @param pattern The input pattern.
     * @param future The future outcome to accumulate.
     */
    public void update(int[] pattern, int[] future) {
        if (!isInitialized) return;

        if (USE_FLAT_MAP) {
            long key = Murmur3.hash64(pattern, 0);
            long signature = Murmur3.hash64(pattern, SIGNATURE_SEED);
            // Delegate entirely to FlatHashMap to handle accumulation and counting
            flatMap.put(key, signature, future);
        } else {
            long key = Murmur3.hash64(pattern);
            int[] history = standardMap.get(key);
            if (history == null) {
                // Create new entry
                standardMap.put(key, future.clone());
            } else {
                // Update existing entry
                for (int i = 0; i < history.length; i++) {
                    history[i] += future[i];
                }
            }
        }
    }
    
    public void forceUpdateDistribution() {
        if (USE_FLAT_MAP && flatMap != null) {
            flatMap.forceUpdateDistribution();
        }
    }
    
    public int size() {
        if (!isInitialized) return 0;
        return USE_FLAT_MAP ? flatMap.size() : standardMap.size();
    }
}
