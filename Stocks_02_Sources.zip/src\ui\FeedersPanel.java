package ui;

import globals.AppConfig;
import channels.DailyData;
import globals.Globals;
import utilities.CleanData;
import utilities.DataLoader;
import utilities.PersistenceUtility;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class FeedersPanel extends JPanel {

    private final JTextField dataLocationTextField;
    private final JTextField cleanDataLocationTextField;
    private final JButton cleanDataButton;
    private final JButton loadDataButton;

    public FeedersPanel() {
        setLayout(new BorderLayout());

        // --- Top: File Feeders ---
        JPanel fileFeedersPanel = new JPanel(new GridBagLayout());
        fileFeedersPanel.setBorder(BorderFactory.createTitledBorder("File Feeders (Local)"));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: Raw Data
        gbc.gridx = 0; gbc.gridy = 0;
        fileFeedersPanel.add(new JLabel("Raw Data File:"), gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        dataLocationTextField = new JTextField();
        dataLocationTextField.setText(AppConfig.appProperties.getProperty("raw_data_location", ""));
        fileFeedersPanel.add(dataLocationTextField, gbc);

        gbc.gridx = 2; gbc.weightx = 0.0;
        JButton fileButton = new JButton("Browse...");
        fileFeedersPanel.add(fileButton, gbc);

        gbc.gridx = 3;
        cleanDataButton = new JButton("Clean Data");
        fileFeedersPanel.add(cleanDataButton, gbc);

        // Row 1: Clean Data
        gbc.gridx = 0; gbc.gridy = 1;
        fileFeedersPanel.add(new JLabel("Clean Data File:"), gbc);

        gbc.gridx = 1; gbc.weightx = 1.0;
        cleanDataLocationTextField = new JTextField();
        cleanDataLocationTextField.setText(AppConfig.appProperties.getProperty("clean_data_location", ""));
        fileFeedersPanel.add(cleanDataLocationTextField, gbc);

        gbc.gridx = 2; gbc.weightx = 0.0;
        JButton chooseCleanFileButton = new JButton("Browse...");
        fileFeedersPanel.add(chooseCleanFileButton, gbc);

        gbc.gridx = 3;
        loadDataButton = new JButton("Load Data");
        fileFeedersPanel.add(loadDataButton, gbc);

        add(fileFeedersPanel, BorderLayout.NORTH);

        // --- Bottom: API Feeders (Placeholder) ---
        JPanel apiFeedersPanel = new JPanel();
        apiFeedersPanel.setBorder(BorderFactory.createTitledBorder("Real-time API Feeders (Future)"));
        apiFeedersPanel.setBackground(Color.LIGHT_GRAY);
        apiFeedersPanel.add(new JLabel("Queue for external real-time data suppliers..."));
        
        add(apiFeedersPanel, BorderLayout.CENTER);

        // --- Event Listeners ---
        fileButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                String rawDataPath = selectedFile.getAbsolutePath();
                dataLocationTextField.setText(rawDataPath);
                PersistenceUtility.setPropertyAndSave("raw_data_location", rawDataPath);
                
                String cleanDataPath = rawDataPath.replace(".txt", ".clean.txt");
                cleanDataLocationTextField.setText(cleanDataPath);
                PersistenceUtility.setPropertyAndSave("clean_data_location", cleanDataPath);
            }
        });

        cleanDataButton.addActionListener(e -> {
            String dataLocation = dataLocationTextField.getText();
            if (dataLocation != null && !dataLocation.trim().isEmpty()) {
                cleanDataButton.setEnabled(false);
                cleanDataButton.setText("Cleaning...");
                new SwingWorker<Void, Void>() {
                    @Override
                    protected Void doInBackground() throws Exception {
                        CleanData.clean(dataLocation);
                        return null;
                    }
                    @Override
                    protected void done() {
                        try {
                            get();
                            JOptionPane.showMessageDialog(FeedersPanel.this, "Data cleaned successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(FeedersPanel.this, "Error cleaning data: " + ex.getCause().getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        } finally {
                            cleanDataButton.setEnabled(true);
                            cleanDataButton.setText("Clean Data");
                        }
                    }
                }.execute();
            }
        });

        chooseCleanFileButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                cleanDataLocationTextField.setText(selectedFile.getAbsolutePath());
                PersistenceUtility.setPropertyAndSave("clean_data_location", selectedFile.getAbsolutePath());
            }
        });

        loadDataButton.addActionListener(e -> {
            String cleanDataLocation = cleanDataLocationTextField.getText();
            if (cleanDataLocation != null && !cleanDataLocation.trim().isEmpty()) {
                loadDataButton.setEnabled(false);
                loadDataButton.setText("Loading...");
                new SwingWorker<Void, Void>() {
                    @Override
                    protected Void doInBackground() throws Exception {
                        DataLoader.load(cleanDataLocation);
                        return null;
                    }

                    @Override
                    protected void done() {
                        try {
                            get();
                            
                            // Calculate Benchmarks
                            if (Globals.allData != null && !Globals.allData.isEmpty()) {
                                DailyData firstDay = Globals.allData.get(0);
                                DailyData lastDay = Globals.allData.get(Globals.allData.size() - 1);
                                if (!firstDay.closePrices.isEmpty() && !lastDay.closePrices.isEmpty()) {
                                    float startPrice = firstDay.closePrices.get(0);
                                    float endPrice = lastDay.closePrices.get(lastDay.closePrices.size() - 1);
                                    double profitPerShare = endPrice - startPrice;

                                    Globals.buyAndHoldProfit1k = profitPerShare * 1000 * 100;
                                    Globals.buyAndHoldProfit2k = profitPerShare * 2000 * 100;
                                    Globals.buyAndHoldProfit3k = profitPerShare * 3000 * 100;
                                }
                            }

                            JOptionPane.showMessageDialog(FeedersPanel.this, "Data loaded for " + Globals.allData.size() + " days.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(FeedersPanel.this, "Error loading data: " + (ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage()), "Error", JOptionPane.ERROR_MESSAGE);
                        } finally {
                            loadDataButton.setEnabled(true);
                            loadDataButton.setText("Load Data");
                        }
                    }
                }.execute();
            }
        });
    }
}
