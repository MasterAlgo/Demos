package utilities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;

public class CleanData {

    public static void clean(String inputFilePath) throws IOException {
        long startTime = System.currentTimeMillis();
        String outputFilePath = inputFilePath.replace(".txt", ".clean.txt");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy,HH:mm");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        // --- Step 1: Read all raw data into a map for efficient lookup ---
        TreeMap<LocalDateTime, String> dataMap = new TreeMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    String[] parts = line.split(",");
                    LocalDateTime dateTime = LocalDateTime.parse(parts[0] + "," + parts[1], formatter);
                    dataMap.put(dateTime, line);
                } catch (Exception e) {
                    // Ignore lines that don't parse correctly
                }
            }
        }

        if (dataMap.isEmpty()) {
            System.out.println("No data found in input file.");
            return;
        }

        // --- Step 2: Iterate through every minute of the trading day and write clean data ---
        final LocalTime tradingStart = LocalTime.of(9, 30);
        final LocalTime tradingEnd = LocalTime.of(16, 0);
        
        long lineCount = 0;
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            LocalDate startDate = dataMap.firstKey().toLocalDate();
            LocalDate endDate = dataMap.lastKey().toLocalDate();

            for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
                
                // 1. Skip Weekends
                DayOfWeek dow = date.getDayOfWeek();
                if (dow == DayOfWeek.SATURDAY || dow == DayOfWeek.SUNDAY) {
                    continue;
                }

                // 2. Skip Holidays (Weekdays with absolutely no data in the raw file)
                LocalDateTime startOfDay = date.atStartOfDay();
                LocalDateTime endOfDay = date.plusDays(1).atStartOfDay();
                if (dataMap.subMap(startOfDay, endOfDay).isEmpty()) {
                    continue;
                }

                for (LocalTime time = tradingStart; !time.isAfter(tradingEnd); time = time.plusMinutes(1)) {
                    LocalDateTime currentDateTime = LocalDateTime.of(date, time);
                    String line = dataMap.get(currentDateTime);

                    if (line != null) {
                        writer.write(line);
                        writer.write(",0"); // Append "0" for isMissing = false
                    } else {
                        // Write placeholder with "1" for isMissing = true
                        writer.write(date.format(dateFormatter));
                        writer.write(",");
                        writer.write(time.format(timeFormatter));
                        writer.write(",");
                        // Use -1.0 for prices and 0 for volume as placeholders
                        writer.write("-1.0,-1.0,-1.0,-1.0,0");
                        writer.write(",1"); // Append "1" for isMissing = true
                    }
                    writer.newLine();
                    lineCount++;
                }
            }
        }

        // --- Step 3: Reporting ---
        long endTime = System.currentTimeMillis();
        double elapsedSeconds = (endTime - startTime) / 1000.0;
        System.out.println("--- Data Cleaning Report ---");
        System.out.println("Elapsed time: " + elapsedSeconds + " seconds");
        System.out.println("Processed records (lines): " + lineCount);
        System.out.println("------------------------------------------");
    }
}
