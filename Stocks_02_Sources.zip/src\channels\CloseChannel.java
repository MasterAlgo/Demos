package channels;

public class CloseChannel extends PriceChannel {
    public CloseChannel() {
        super("Close");
    }

    @Override
    protected float getPrice(DailyData day, int index) {
        return day.closePrices.get(index);
    }
}
