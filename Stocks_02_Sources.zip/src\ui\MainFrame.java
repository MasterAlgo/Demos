package ui;

import utilities.PersistenceUtility;

import javax.swing.JFrame;

public class MainFrame extends JFrame {
    public MainFrame() {
        // Load properties on startup
        PersistenceUtility.loadProperties();

        setTitle("Stocks_02 - Canonical Implementation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // Add the MainPanel which contains the layout
        add(new MainPanel());
    }
}