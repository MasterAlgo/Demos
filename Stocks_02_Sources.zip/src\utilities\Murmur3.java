package utilities;

public class Murmur3 {

    private static final long C1 = 0x87c37b91114253d5L;
    private static final long C2 = 0x4cf5ad432745937fL;

    /**
     * Calculates the 64-bit Murmur3 hash of an integer array with a default seed.
     *
     * @param data The input integer array.
     * @return The 64-bit hash.
     */
    public static long hash64(int[] data) {
        return hash64(data, 0);
    }

    /**
     * Calculates the 64-bit Murmur3 hash of an integer array with a specific seed.
     *
     * @param data The input integer array.
     * @param seed The seed value.
     * @return The 64-bit hash.
     */
    public static long hash64(int[] data, long seed) {
        long h1 = seed;
        int length = data.length;
        int i = 0;

        // Process pairs of integers as 64-bit blocks
        // Since input is int[], each element is 4 bytes.
        // We need to process 8 bytes (2 ints) at a time.
        while (i < length - 1) {
            long k1 = ((long) data[i] & 0xffffffffL) | (((long) data[i + 1] & 0xffffffffL) << 32);
            i += 2;

            k1 *= C1;
            k1 = Long.rotateLeft(k1, 31);
            k1 *= C2;

            h1 ^= k1;
            h1 = Long.rotateLeft(h1, 27);
            h1 = h1 * 5 + 0x52dce729;
        }

        // Process remaining int if length is odd
        if (i < length) {
            long k1 = (long) data[i] & 0xffffffffL;
            k1 *= C1;
            k1 = Long.rotateLeft(k1, 31);
            k1 *= C2;
            h1 ^= k1;
        }

        // Finalization
        h1 ^= length * 4L; // Length in bytes
        h1 ^= h1 >>> 33;
        h1 *= 0xff51afd7ed558ccdL;
        h1 ^= h1 >>> 33;
        h1 *= 0xc4ceb9fe1a85ec53L;
        h1 ^= h1 >>> 33;

        return h1;
    }
}
