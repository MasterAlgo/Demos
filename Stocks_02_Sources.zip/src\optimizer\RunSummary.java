package optimizer;

public class RunSummary {
    public final long annSize;
    public final int tokenDictionarySize;

    public RunSummary(long annSize, int tokenDictionarySize) {
        this.annSize = annSize;
        this.tokenDictionarySize = tokenDictionarySize;
    }
}
