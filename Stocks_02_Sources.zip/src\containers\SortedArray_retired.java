package containers;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

public class SortedArray_retired {

    public final int maxRecords;
    private final int keyLength;
    private final int valueLength;
    private final boolean isLtr;

    private final int[] keyData;
    private final float[] valueData;

    public int size = 0;
    private boolean overfill = false;

    public SortedArray_retired(int maxRecords, int keyLength, int valueLength, boolean isLtr) {
        if (maxRecords <= 0 || keyLength <= 0 || valueLength <= 0) {
            throw new IllegalArgumentException("Dimensions must be positive.");
        }
        this.maxRecords = maxRecords;
        this.keyLength = keyLength;
        this.valueLength = valueLength;
        this.isLtr = isLtr;

        this.keyData = new int[maxRecords * keyLength];
        this.valueData = new float[maxRecords * valueLength];
    }

    public void clear() {
        this.size = 0;
        this.overfill = false;
    }

    public boolean isFull() {
        return this.size >= this.maxRecords;
    }

    public boolean hasOverfilled() {
        return this.overfill;
    }

    public int getSize() {
        return this.size;
    }

    public int getKeyLength() {
        return this.keyLength;
    }

    public int[] getKey(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for size " + size);
        }
        int[] key = new int[keyLength];
        System.arraycopy(keyData, index * keyLength, key, 0, keyLength);
        return key;
    }

    public float[] getValue(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for size " + size);
        }
        float[] value = new float[valueLength];
        System.arraycopy(valueData, index * valueLength, value, 0, valueLength);
        return value;
    }

    public int find(int[] key) {
        int low = 0;
        int high = this.size - 1;
        while (low <= high) {
            int mid = (low + high) >>> 1;
            int cmp = compareKey(mid, key);
            if (cmp < 0) {
                low = mid + 1;
            } else if (cmp > 0) {
                high = mid - 1;
            } else {
                return mid; // Key found
            }
        }
        return -(low + 1);  // Key not found, returns (-insertionPoint - 1)
    }

    public void updateValueByIndex(int index, float[] valuesToAdd) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Update index " + index + " is out of bounds for size " + size);
        }
        int valueStart = index * this.valueLength;
        for (int i = 0; i < this.valueLength; i++) {
            this.valueData[valueStart + i] += valuesToAdd[i];
        }
    }

    public boolean insertValueAtIndex(int index, int[] key, float[] value) {
        if (isFull()) {
            this.overfill = true;
            return false;
        }
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Insert index " + index + " is out of bounds for size " + size);
        }

        // Shift existing elements if necessary
        if (index < this.size) {
            int keyStart = index * this.keyLength;
            int valueStart = index * this.valueLength;
            System.arraycopy(keyData, keyStart, keyData, keyStart + this.keyLength, (this.size - index) * this.keyLength);
            System.arraycopy(valueData, valueStart, valueData, valueStart + this.valueLength, (this.size - index) * this.valueLength);
        }

        // Insert the new element
        int keyInsertPos = index * this.keyLength;
        int valueInsertPos = index * this.valueLength;
        System.arraycopy(key, 0, keyData, keyInsertPos, this.keyLength);
        System.arraycopy(value, 0, valueData, valueInsertPos, this.valueLength);

        this.size++;
        return true;
    }

    public void mergeInto(SortedArray_retired target) {
        if (target.keyLength != this.keyLength || target.valueLength != this.valueLength) {
            throw new IllegalArgumentException("Target array must have the same key and value lengths.");
        }

        for (int i = 0; i < this.size; i++) {
            int[] key = getKey(i);
            float[] value = getValue(i);

            int searchResult = target.find(key);
            if (searchResult >= 0) {
                // Found, so modify
                target.updateValueByIndex(searchResult, value);
            } else {
                // Not found, so insert
                int insertionPoint = -searchResult - 1;
                if (!target.insertValueAtIndex(insertionPoint, key, value)) {
                    // If insert fails, the target is full. We can't add more.
                    return; // Stop merging if target is full
                }
            }
        }
    }

    public void dump() {
        System.out.println("--- SortedArray_retired Dump (Size: " + size + " / " + maxRecords + ") ---");
        if (size == 0) {
            System.out.println("(empty)");
            return;
        }
        for (int i = 0; i < size; i++) {
            System.out.printf("Index %d: Key: %s, Value: %s\n",
                    i,
                    Arrays.toString(getKey(i)),
                    Arrays.toString(getValue(i)));
        }
        System.out.println("--- End Dump ---");
    }

    public void save(DataOutputStream dos) throws IOException {
        dos.writeInt(size);
        dos.writeInt(keyLength);
        dos.writeInt(valueLength);
        dos.writeBoolean(isLtr);

        int keyDataCount = size * keyLength;
        if (keyDataCount > 0) {
            byte[] keyBuffer = new byte[keyDataCount * 4];
            ByteBuffer.wrap(keyBuffer).order(ByteOrder.BIG_ENDIAN).asIntBuffer().put(keyData, 0, keyDataCount);
            dos.write(keyBuffer);
        }

        int valueDataCount = size * valueLength;
        if (valueDataCount > 0) {
            byte[] valueBuffer = new byte[valueDataCount * 4];
            ByteBuffer.wrap(valueBuffer).order(ByteOrder.BIG_ENDIAN).asFloatBuffer().put(valueData, 0, valueDataCount);
            dos.write(valueBuffer);
        }
    }

    public void load(DataInputStream dis) throws IOException {
        this.size = dis.readInt();
        int loadedKeyLength = dis.readInt();
        int loadedValueLength = dis.readInt();
        boolean loadedIsLtr = dis.readBoolean();

        if (loadedKeyLength != this.keyLength || loadedValueLength != this.valueLength || loadedIsLtr != this.isLtr) {
            throw new IOException("Mismatched model parameters.");
        }

        if (this.size > this.maxRecords) {
            throw new IOException("Data size exceeds max records.");
        }

        int keyBytesToRead = this.size * this.keyLength * 4;
        if(keyBytesToRead > 0) {
            byte[] keyBuffer = new byte[keyBytesToRead];
            dis.readFully(keyBuffer);
            ByteBuffer.wrap(keyBuffer).order(ByteOrder.BIG_ENDIAN).asIntBuffer().get(this.keyData, 0, this.size * this.keyLength);
        }

        int valueBytesToRead = this.size * this.valueLength * 4;
        if(valueBytesToRead > 0) {
            byte[] valueBuffer = new byte[valueBytesToRead];
            dis.readFully(valueBuffer);
            ByteBuffer.wrap(valueBuffer).order(ByteOrder.BIG_ENDIAN).asFloatBuffer().get(this.valueData, 0, this.size * this.valueLength);
        }
    }

    private int compareKey(int index, int[] key) {
        if (key.length != this.keyLength) {
            return this.keyLength - key.length;
        }
        int keyStart = index * this.keyLength;
        for (int i = 0; i < this.keyLength; i++) {
            int diff = this.keyData[keyStart + i] - key[i];
            if (diff != 0) {
                return diff;
            }
        }
        return 0;
    }
}
