package tests;

import channels.Channel;
import channels.ChannelManager;
import channels.helpers.DiscretizedWeightedBinner;
import globals.AppConfig;
import channels.DailyData;
import globals.Globals;
import utilities.DataLoader;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChannelsTestController {

    private final ChannelsTestFrame frame;
    private final ChannelManager channelManager;
    
    private int currentDayIndex = 0;
    private int currentMinuteIndex = 0;
    private boolean isRunning = false;
    
    private BufferedReader rawReader;
    private String nextRawLine; 
    private List<String> currentDayRawLines = new ArrayList<>();
    private String currentDayCacheDate = "";
    
    // Verification Helpers
    private DiscretizedWeightedBinner binner;
    private int volGradeCount;
    private int priceGranularity;
    private int priceReferencePoint;

    public ChannelsTestController(ChannelsTestFrame frame) {
        this.frame = frame;
        this.channelManager = new ChannelManager();
        
        initialize();
    }

    private void initialize() {
        // Properties are assumed to be loaded by the main application into AppConfig
        
        if (Globals.allData == null || Globals.allData.isEmpty()) {
            frame.appendLog("Loading data...");
            String cleanPath = AppConfig.appProperties.getProperty("clean_data_location");
            if (cleanPath != null) {
                try {
                    DataLoader.load(cleanPath);
                } catch (IOException e) {
                    frame.appendLog("ERROR: Failed to load data: " + e.getMessage());
                    return;
                }
            } else {
                frame.appendLog("ERROR: clean_data_location not found.");
                return;
            }
        }
        
        channelManager.initialize();
        setupVerificationHelpers();
        
        String rawFilePath = AppConfig.appProperties.getProperty("raw_data_location");
        if (rawFilePath != null) {
            try {
                rawReader = new BufferedReader(new FileReader(rawFilePath));
                nextRawLine = rawReader.readLine();
            } catch (IOException e) {
                frame.appendLog("ERROR: Could not open raw file: " + e.getMessage());
            }
        }
        
        frame.appendLog("Initialization Complete. Ready.");
        // Start from index 1 (9:31) so we have a valid reference point (9:30) within the same day
        currentMinuteIndex = 1;
    }
    
    private void setupVerificationHelpers() {
        // Load Price Configuration
        try {
            priceGranularity = Integer.parseInt(AppConfig.channelProperties.getProperty("OHLC_priceGranularity", "100"));
        } catch (NumberFormatException e) {
            priceGranularity = 100;
        }
        
        try {
            priceReferencePoint = Integer.parseInt(AppConfig.channelProperties.getProperty("OHLC_referencePoint", "-1"));
        } catch (NumberFormatException e) {
            priceReferencePoint = -1;
        }

        // Load Volume Configuration
        try {
            volGradeCount = Integer.parseInt(AppConfig.channelProperties.getProperty("Volume_gradeCount", "10"));
        } catch (NumberFormatException e) {
            volGradeCount = 10;
        }

        int step = 1000;
        try {
            step = Integer.parseInt(AppConfig.channelProperties.getProperty("Volume_binnerStep", "1000"));
        } catch (NumberFormatException e) { step = 1000; }
        
        boolean weightByVol = Boolean.parseBoolean(AppConfig.channelProperties.getProperty("Volume_binnerWeightByVolume", "true"));
        binner = new DiscretizedWeightedBinner(volGradeCount, step);

        for (DailyData day : Globals.allData) {
            for (int i = 0; i < day.volumes.size(); i++) {
                if (day.isMissing.get(i)) continue;
                int vol = day.volumes.get(i);
                if (vol < 0) vol = 0;
                binner.add(vol, weightByVol);
            }
        }
    }

    public void nextStep() {
        if (Globals.allData == null || Globals.allData.isEmpty()) return;

        DailyData day = Globals.allData.get(currentDayIndex);
        
        if (currentMinuteIndex + 10 >= day.closePrices.size()) {
            currentDayIndex++;
            currentMinuteIndex = 1; // Reset to 1 for new day
            if (currentDayIndex >= Globals.allData.size()) {
                frame.appendLog("End of Data Reached.");
                stopAutoRun();
                return;
            }
            day = Globals.allData.get(currentDayIndex);
        }

        int[][] matrix = channelManager.getCombinedMatrix(Globals.allData, currentDayIndex, currentMinuteIndex);
        if (matrix == null) {
            frame.appendLog("Matrix null at " + day.date + " " + currentMinuteIndex);
            currentMinuteIndex++;
            return;
        }

        StringBuilder leftSb = new StringBuilder();
        leftSb.append("Day: ").append(day.date).append(" | Min: ").append(currentMinuteIndex).append("\n\n");
        
        int rowIdx = 0;
        for (String channelName : AppConfig.activeChannels.keySet()) {
            if (rowIdx >= matrix.length) break;
            
            String label = String.format("%-6s", channelName.substring(0, Math.min(5, channelName.length())) + ":");
            leftSb.append(label);
            
            for (int c = 0; c < matrix[rowIdx].length; c++) {
                if (matrix[rowIdx][c] == Globals.MISSING_TOKEN) {
                    leftSb.append("   #");
                } else {
                    leftSb.append(String.format("%4d", matrix[rowIdx][c]));
                }
            }
            leftSb.append("\n");
            rowIdx++;
        }
        frame.setLeftText(leftSb.toString());

        List<String> windowRawLines = fetchRawLinesForWindow(day, currentMinuteIndex, 10);
        
        StringBuilder rightSb = new StringBuilder();
        for (String line : windowRawLines) {
            rightSb.append(line).append("\n");
        }
        frame.setRightText(rightSb.toString());
        
        // Check for missing data pause
        if (frame.isPauseOnMissing()) {
            for (String line : windowRawLines) {
                if (line.contains("[MISSING IN RAW]")) {
                    stopAutoRun();
                    frame.appendLog("PAUSED: Missing data detected.");
                    break;
                }
            }
        }

        String result = verify(matrix, windowRawLines, day, currentMinuteIndex);
        frame.setBottomText(result);
        
        if (result.contains("FAIL")) {
            stopAutoRun();
            frame.appendLog("STOPPED due to verification failure.");
        }

        currentMinuteIndex++;
    }

    private List<String> fetchRawLinesForWindow(DailyData day, int startMinuteIdx, int windowSize) {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < windowSize; i++) {
            int targetIdx = startMinuteIdx + i;
            
            if (day.isMissing.get(targetIdx)) {
                result.add("[MISSING IN RAW]");
                continue;
            }
            
            int targetTime = day.minutes.get(targetIdx);
            String rawLine = findRawLineCached(day.date.toString(), targetTime);
            result.add(rawLine != null ? rawLine : "[ERROR: Raw line not found for non-missing data]");
        }
        return result;
    }

    private String findRawLineCached(String date, int time) {
        if (!date.equals(currentDayCacheDate)) {
            loadDayCache(date);
        }
        
        int totalMinutes = time + (9 * 60 + 30);
        int h = totalMinutes / 60;
        int m = totalMinutes % 60;
        
        String timeStr = String.format("%02d:%02d", h, m);
        
        for (String line : currentDayRawLines) {
            if (line.contains(timeStr)) return line;
        }
        return null;
    }

    private void loadDayCache(String date) {
        currentDayRawLines.clear();
        currentDayCacheDate = date;
        
        try {
            while (nextRawLine != null) {
                String[] parts = nextRawLine.split(",");
                if (parts.length < 1) {
                    nextRawLine = rawReader.readLine();
                    continue;
                }
                
                int dateComp = compareDates(parts[0], date);
                
                if (dateComp < 0) {
                    nextRawLine = rawReader.readLine(); 
                } else if (dateComp == 0) {
                    currentDayRawLines.add(nextRawLine);
                    nextRawLine = rawReader.readLine();
                } else {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int compareDates(String rawDate, String targetDateISO) {
        String[] rawParts = rawDate.split("/");
        String[] targetParts = targetDateISO.split("-");
        
        if (rawParts.length < 3 || targetParts.length < 3) return rawDate.compareTo(targetDateISO);
        
        int y1 = Integer.parseInt(rawParts[2]);
        int y2 = Integer.parseInt(targetParts[0]);
        if (y1 != y2) return y1 - y2;
        
        int m1 = Integer.parseInt(rawParts[0]);
        int m2 = Integer.parseInt(targetParts[1]);
        if (m1 != m2) return m1 - m2;
        
        int d1 = Integer.parseInt(rawParts[1]);
        int d2 = Integer.parseInt(targetParts[2]);
        return d1 - d2;
    }

    private String verify(int[][] matrix, List<String> rawLines, DailyData day, int minuteIndex) {
        StringBuilder sb = new StringBuilder();
        
        int rowIdx = 0;
        for (Map.Entry<String, Channel> entry : AppConfig.activeChannels.entrySet()) {
            String name = entry.getKey();
            int[] row = matrix[rowIdx];
            
            if (name.equals("Volume")) {
                verifyVolume(row, rawLines, sb, binner);
            } else if (name.equals("Open") || name.equals("High") || name.equals("Low") || name.equals("Close")) {
                int rawColIdx = 2; // Default Open
                if (name.equals("High")) rawColIdx = 3;
                else if (name.equals("Low")) rawColIdx = 4;
                else if (name.equals("Close")) rawColIdx = 5;
                
                int refIdx = minuteIndex + priceReferencePoint;
                boolean refIsMissing = refIdx < 0 || day.isMissing.get(refIdx);
                float specificRefPrice = -1;
                
                if (!refIsMissing) {
                    int refTime = day.minutes.get(refIdx);
                    String refLine = findRawLineCached(day.date.toString(), refTime);
                    if (refLine != null) {
                         specificRefPrice = Float.parseFloat(refLine.split(",")[rawColIdx]);
                    } else {
                        refIsMissing = true; // Treat as missing if raw line not found
                    }
                }
                
                verifyPrice(row, rawLines, sb, name, rawColIdx, specificRefPrice, refIsMissing, priceGranularity);
            }
            
            rowIdx++;
        }
        
        if (sb.length() == 0) {
            return "Verification PASSED for this step.";
        } else {
            return sb.toString();
        }
    }
    
    private void verifyPrice(int[] row, List<String> rawLines, StringBuilder sb, String name, int rawColIdx, float refPrice, boolean refIsMissing, int granularity) {
        for (int i = 0; i < row.length; i++) {
            String currLine = rawLines.get(i);
            
            if (refIsMissing) {
                if (row[i] != Globals.MISSING_TOKEN) {
                    sb.append(String.format("[FAIL] %s Idx %d: Ref is MISS, Exp #, Got %d\n", name, i, row[i]));
                }
                continue;
            }
            
            if (currLine.startsWith("[")) {
                if (row[i] != Globals.MISSING_TOKEN) {
                    sb.append(String.format("[FAIL] %s Idx %d: Exp #, Got %d\n", name, i, row[i]));
                }
                continue;
            }
            
            try {
                float currVal = Float.parseFloat(currLine.split(",")[rawColIdx]);
                int expected = Math.round((currVal - refPrice) * granularity);
                int actual = row[i];
                
                if (expected != actual) {
                    sb.append(String.format("[FAIL] %s Idx %d: Exp %d, Got %d (%.2f - %.2f)\n", 
                        name, i, expected, actual, currVal, refPrice));
                }
            } catch (Exception e) {
                sb.append(name + " Parse Error at Idx " + i + "\n");
            }
        }
    }

    private void verifyVolume(int[] row, List<String> rawLines, StringBuilder sb, DiscretizedWeightedBinner binner) {
        for (int i = 0; i < row.length; i++) {
            String currLine = rawLines.get(i);
            
            if (currLine.startsWith("[")) {
                if (row[i] != Globals.MISSING_TOKEN) {
                    sb.append(String.format("[FAIL] Vol Idx %d: Exp #, Got %d\n", i, row[i]));
                }
                continue;
            }
            
            try {
                long vol = Long.parseLong(currLine.split(",")[6]);
                if (vol < 0) vol = 0;
                
                int expected = binner.binIndex(vol);
                int actual = row[i];
                
                if (expected != actual) {
                    sb.append(String.format("[FAIL] Vol Idx %d: Exp %d, Got %d (Vol: %d)\n", 
                        i, expected, actual, vol));
                }
            } catch (Exception e) {
                sb.append("Vol Parse Error at Idx " + i + "\n");
            }
        }
    }
    
    public void startAutoRun() {
        isRunning = true;
        new Thread(() -> {
            while (isRunning) {
                try {
                    SwingUtilities.invokeAndWait(this::nextStep);
                    Thread.sleep(50);
                } catch (Exception e) {
                    stopAutoRun();
                }
            }
        }).start();
    }

    public void stopAutoRun() {
        isRunning = false;
        frame.stopRun();
    }
}
