package channels;

public class OpenChannel extends PriceChannel {
    public OpenChannel() {
        super("Open");
    }

    @Override
    protected float getPrice(DailyData day, int index) {
        return day.openPrices.get(index);
    }
}
