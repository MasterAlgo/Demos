package globals;

import channels.Channel;
import java.util.*;

public class AppConfig {
    // Centralized Configuration
    public static final Properties appProperties = new Properties();
    public static final Properties channelProperties = new Properties();

    // Map to hold the parsed options from parameters.properties
    public static final Map<String, List<String>> parametersMap = new HashMap<>();

    public static final List<String> activeChannelNames = new ArrayList<>();
    
    // Holds the active channel instances. Using LinkedHashMap to preserve order.
    public static final Map<String, Channel> activeChannels = new LinkedHashMap<>();

    // Tuning Parameters
    public static int TRAINING_WINDOW_SIZE = 10;
    public static int PREDICTION_WINDOW_SIZE = 10;
    public static int MIN_ACTUAL_TOKENS = 0;
    public static int PATTERNS_CONTAINER_SIZE = 150_000_000;
    
    // Removed TOTAL_WINDOW_SIZE as agreed, using TRAINING_WINDOW_SIZE instead.

    public static int minSequence;
    public static int maxSequence;
    public static int tokenSize;

    public static void updateStaticFields() {
        try {
            TRAINING_WINDOW_SIZE = Integer.parseInt(appProperties.getProperty("TRAINING_WINDOW_SIZE", "10"));
            PREDICTION_WINDOW_SIZE = Integer.parseInt(appProperties.getProperty("PREDICTION_WINDOW_SIZE", "10"));
            MIN_ACTUAL_TOKENS = Integer.parseInt(appProperties.getProperty("MIN_ACTUAL_TOKENS", "0"));
            PATTERNS_CONTAINER_SIZE = Integer.parseInt(appProperties.getProperty("Patterns_Container_Size", "150000000"));
            
            // Also update other tuning parameters if they are in appProperties
            if (appProperties.containsKey("minSynapticInputs")) {
                minSequence = Integer.parseInt(appProperties.getProperty("minSynapticInputs"));
            }
            if (appProperties.containsKey("maxSynapticInputs")) {
                maxSequence = Integer.parseInt(appProperties.getProperty("maxSynapticInputs"));
            }
            if (appProperties.containsKey("tokenSize")) {
                tokenSize = Integer.parseInt(appProperties.getProperty("tokenSize"));
            }
            
            // Update Globals from properties
            if (appProperties.containsKey("K_FACTOR")) {
                Globals.K_FACTOR = Integer.parseInt(appProperties.getProperty("K_FACTOR"));
            }
            if (appProperties.containsKey("MIN_PATTERN_COUNT")) {
                Globals.MIN_PATTERN_COUNT = Integer.parseInt(appProperties.getProperty("MIN_PATTERN_COUNT"));
            }
            if (appProperties.containsKey("TRADE_THRESHOLD")) {
                Globals.TRADE_THRESHOLD = Float.parseFloat(appProperties.getProperty("TRADE_THRESHOLD"));
            }
            
            // Update Display/Log Flags
            if (appProperties.containsKey("EXTENDED_LOGGING")) {
                Globals.EXTENDED_LOGGING = Boolean.parseBoolean(appProperties.getProperty("EXTENDED_LOGGING"));
            }
            if (appProperties.containsKey("SHOW_INTRADAY_CHART")) {
                Globals.SHOW_INTRADAY_CHART = Boolean.parseBoolean(appProperties.getProperty("SHOW_INTRADAY_CHART"));
            }
            if (appProperties.containsKey("SHOW_PROFIT_CHART")) {
                Globals.SHOW_PROFIT_CHART = Boolean.parseBoolean(appProperties.getProperty("SHOW_PROFIT_CHART"));
            }
            // Update Heuristic Flag
            if (appProperties.containsKey("HEURISTIC_ENABLED")) {
                Globals.HEURISTIC_ENABLED = Boolean.parseBoolean(appProperties.getProperty("HEURISTIC_ENABLED"));
            }
            // Update Sentiment Threshold
            if (appProperties.containsKey("SENTIMENT_THRESHOLD")) {
                Globals.SENTIMENT_THRESHOLD = Float.parseFloat(appProperties.getProperty("SENTIMENT_THRESHOLD"));
            }
            // Update Dynamic Min Pattern Count
            if (appProperties.containsKey("MIN_PATTERN_COUNT_SCALING")) {
                Globals.MIN_PATTERN_COUNT_SCALING = appProperties.getProperty("MIN_PATTERN_COUNT_SCALING");
            }
            if (appProperties.containsKey("REFERENCE_ANN_SIZE")) {
                Globals.REFERENCE_ANN_SIZE = Long.parseLong(appProperties.getProperty("REFERENCE_ANN_SIZE"));
            }

        } catch (NumberFormatException e) {
            System.err.println("Error parsing configuration properties: " + e.getMessage());
        }
    }
}
