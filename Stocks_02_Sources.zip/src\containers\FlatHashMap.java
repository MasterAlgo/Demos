package containers;

import globals.Globals;
import java.io.*;
import java.util.Arrays;
import java.util.Random;

/**
 * A specialized, memory-efficient hash map for long keys and int[] values.
 * Uses open addressing with linear probing to avoid object overhead.
 * Now supports a secondary 64-bit signature to virtually eliminate collisions.
 */
public class FlatHashMap {

    private static final int DEFAULT_CAPACITY = 16;
    private static final float LOAD_FACTOR = 0.7f;

    private long[] keys;
    private long[] signatures; // Secondary hash for verification
    private int[][] values;
    private byte[] state; // 0 = Empty, 1 = Occupied

    private int size;
    private int capacity;
    private int threshold;

    public int[] keysDistribution = new int[100];

    public FlatHashMap() {
        this(DEFAULT_CAPACITY);
    }

    public FlatHashMap(int initialCapacity) {
        // Calculate capacity to ensure we can hold 'initialCapacity' items 
        // without exceeding the LOAD_FACTOR.
        // This ensures the map is large enough to support the user's requested limit safely.
        this.capacity = tableSizeFor((int) (initialCapacity / LOAD_FACTOR) + 1);
        
        // Set the threshold exactly to the user's requested limit.
        this.threshold = initialCapacity;

        this.keys = new long[capacity];
        this.signatures = new long[capacity];
        this.values = new int[capacity][];
        this.state = new byte[capacity];
        this.size = 0;
    }

    /**
     * Retrieves the value associated with the key and signature.
     * @param key The primary long key (Hash 1).
     * @param signature The secondary long signature (Hash 2).
     * @return The int[] value, or null if not found.
     */
    public int[] get(long key, long signature) {
        int idx = (int) (hash(key) & (capacity - 1));
        
        // Linear probing
        while (state[idx] != 0) {
            if (keys[idx] == key && signatures[idx] == signature) {
                return values[idx];
            }
            idx = (idx + 1) & (capacity - 1);
        }
        return null;
    }

    /**
     * Inserts or updates a value.
     * @param key The primary long key (Hash 1).
     * @param signature The secondary long signature (Hash 2).
     * @param value The int[] value (raw, without count).
     */
    public void put(long key, long signature, int[] value) {
        if (size >= threshold) {
            // Instead of resizing, we compact the arrays to save memory
            compactArrays();
        }

        int idx = (int) (hash(key) & (capacity - 1));

        while (state[idx] != 0) {
            if (keys[idx] == key && signatures[idx] == signature) {
                // Update existing
                int countIdx = values[idx].length - 1;
                
                // Accumulate values
                for(int i = 0; i < value.length; i++){
                    values[idx][i] += value[i];
                }
                
                // Increment count
                values[idx][countIdx]++;
                
                return;
            }
            idx = (idx + 1) & (capacity - 1);
        }

        // Insert new
        keys[idx] = key;
        signatures[idx] = signature;
        
        // Create new array with extra slot for count
        int[] stored = new int[value.length + 1];
        System.arraycopy(value, 0, stored, 0, value.length);
        stored[value.length] = 1; // Initial count
        values[idx] = stored;
        
        state[idx] = 1;
         size++;
    }

    /**
     * Inserts a stored value (already containing count) directly.
     * Used during compaction rebuild.
     */
    private void putStored(long key, long signature, int[] storedValue) {
        int idx = (int) (hash(key) & (capacity - 1));

        while (state[idx] != 0) {
            if (keys[idx] == key && signatures[idx] == signature) {
                // Should not happen during rebuild of unique keys
                values[idx] = storedValue;
                return;
            }
            idx = (idx + 1) & (capacity - 1);
        }

        keys[idx] = key;
        signatures[idx] = signature;
        values[idx] = storedValue;
        state[idx] = 1;
        size++;
    }

    public int size() {
        return size;
    }

    private void compactArrays() {
        Globals.STATE = "Compacting patterns...";
        File tempFile = new File("patterns_dump.tmp");
        Random random = new Random();
        int keptCount = 0;
        
        // Reset distribution for "Before" snapshot
        keysDistribution = new int[100];

        // Update UI - Start
        if (Globals.annParamsPanel != null) {
            Globals.annParamsPanel.updateCompactingProgress("Starting...", 0);
        }

        // 1. Dump Phase (and collect Before distribution)
        try (DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tempFile)))) {
            int updateInterval = capacity / 100; // Update every 1%
            if (updateInterval == 0) updateInterval = 1;

            for (int i = 0; i < capacity; i++) {
                if (i % updateInterval == 0 && Globals.annParamsPanel != null) {
                    int percent = (int) ((long) i * 100 / capacity);
                    Globals.annParamsPanel.updateCompactingProgress("Dumping... " + percent + "%", percent);
                }

                if (state[i] == 1) {
                    int[] val = values[i];
                    // Check occurrence count (last element)
                    int count = val[val.length - 1];


                    boolean keep = false;
                    if (count > 1) {
                        keep = true;
                    } else {
                        // Keep only a percentage of single-occurrence patterns
                        if (random.nextFloat() > Globals.REMOVE_THRESHOLD_PERCENT) {
                            keep = true;
                        }
                    }

                    if (keep) {
                        dos.writeLong(keys[i]);
                        dos.writeLong(signatures[i]);
                        dos.writeInt(val.length);
                        for (int v : val) {
                            dos.writeInt(v);
                        }
                        keptCount++;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            Globals.STATE = "Error during compaction";
            if (Globals.annParamsPanel != null) {
                Globals.annParamsPanel.updateCompactingProgress("Error", 0);
            }
            return; // Abort if dump fails
        }
        

        // 2. Clear Phase
        Arrays.fill(keys, 0L);
        Arrays.fill(signatures, 0L);
        Arrays.fill(values, null);
        Arrays.fill(state, (byte) 0);
        size = 0;
        
        // Reset distribution for "After" snapshot
        keysDistribution = new int[100];

        // 3. Rebuild Phase (and collect After distribution)
        try (DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(tempFile)))) {
            int updateInterval = keptCount / 100; // Update every 1%
            if (updateInterval == 0) updateInterval = 1;

            for (int i = 0; i < keptCount; i++) {
                if (i % updateInterval == 0 && Globals.annParamsPanel != null) {
                    int percent = (int) ((long) i * 100 / keptCount);
                    Globals.annParamsPanel.updateCompactingProgress("Populating... " + percent + "%", percent);
                }

                long key = dis.readLong();
                long signature = dis.readLong();
                int len = dis.readInt();
                int[] val = new int[len];
                for (int j = 0; j < len; j++) {
                    val[j] = dis.readInt();
                }
                
                // Collect "After" distribution
                int count = val[val.length - 1];
                if (count < 100) keysDistribution[count]++;
                else keysDistribution[99]++;
                
                putStored(key, signature, val);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Globals.STATE = "Error during rebuild";
            if (Globals.annParamsPanel != null) {
                Globals.annParamsPanel.updateCompactingProgress("Error", 0);
            }
        }

        // 4. Cleanup
        if (tempFile.exists()) {
            tempFile.delete();
        }
        
        Globals.STATE = "Processing...";
        if (Globals.annParamsPanel != null) {
            Globals.annParamsPanel.updateCompactingProgress("Idle", 0);
            int countAbove = countPatternsAboveThreshold(Globals.MIN_PATTERN_COUNT);
            Globals.annParamsPanel.updateDistributionGraph(keysDistribution, countAbove);
        }
        System.out.println("Compaction complete. Size reduced to: " + size);
    }
    
    /**
     * Manually calculates and updates the distribution graph.
     * Useful for end-of-run visualization.
     */
    public void forceUpdateDistribution() {
        keysDistribution = new int[100];
        
        for (int i = 0; i < capacity; i++) {
            if (state[i] == 1) {
                int[] val = values[i];
                int count = val[val.length - 1];
                if (count < 100) keysDistribution[count]++;
                else keysDistribution[99]++;
            }
        }
        
        if (Globals.annParamsPanel != null) {
            int countAbove = countPatternsAboveThreshold(Globals.MIN_PATTERN_COUNT);
            Globals.annParamsPanel.updateDistributionGraph(keysDistribution, countAbove);
        }
    }

    public int countPatternsAboveThreshold(int threshold) {
        int count = 0;
        for (int i = 0; i < capacity; i++) {
            if (state[i] == 1) {
                int[] val = values[i];
                if (val[val.length - 1] >= threshold) {
                    count++;
                }
            }
        }
        return count;
    }

    // Murmur3-like mixer for the hash to ensure good distribution
    private static long hash(long key) {
        key ^= (key >>> 33);
        key *= 0xff51afd7ed558ccdL;
        key ^= (key >>> 33);
        key *= 0xc4ceb9fe1a85ec53L;
        key ^= (key >>> 33);
        return key;
    }

    private static int tableSizeFor(int cap) {
        int n = cap - 1;
        n |= n >>> 1;
        n |= n >>> 2;
        n |= n >>> 4;
        n |= n >>> 8;
        n |= n >>> 16;
        return (n < 0) ? 1 : (n >= 1 << 30) ? 1 << 30 : n + 1;
    }
}
