package ui;

import channels.DailyData;
import javax.swing.*;
import java.awt.*;
import java.util.Collections;
import java.util.List;

public class IntradayChartFrame extends JFrame {

    private final ChartPanel chartPanel;

    public IntradayChartFrame() {
        setTitle("Intraday Trade Chart");
        setSize(1200, 600);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); // Don't exit app, just hide
        setLocationRelativeTo(null);

        chartPanel = new ChartPanel();
        add(chartPanel);
    }

    public void updateChart(DailyData dayData, int entryIndex, int exitIndex, float predictedChange, float patternCount) {
        chartPanel.setData(dayData, entryIndex, exitIndex, predictedChange, patternCount);
        SwingUtilities.invokeLater(() -> {
            if (!isVisible()) {
                setVisible(true);
            }
            repaint();
        });
    }

    private static class ChartPanel extends JPanel {
        private DailyData dayData;
        private int entryIndex = -1;
        private int exitIndex = -1;
        private float predictedChange = 0;
        private float patternCount = 0;

        public ChartPanel() {
            setBackground(Color.BLACK);
        }

        public void setData(DailyData dayData, int entryIndex, int exitIndex, float predictedChange, float patternCount) {
            this.dayData = dayData;
            this.entryIndex = entryIndex;
            this.exitIndex = exitIndex;
            this.predictedChange = predictedChange;
            this.patternCount = patternCount;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (dayData == null || dayData.closePrices.isEmpty()) {
                g.setColor(Color.WHITE);
                g.drawString("No Data", getWidth() / 2, getHeight() / 2);
                return;
            }

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int panelWidth = getWidth() - 40; // Margins
            int panelHeight = getHeight() - 40;
            int xOffset = 20;
            int yOffset = 20;

            // Find Min/Max for scaling (ignoring <= 0 values)
            float minPrice = Float.MAX_VALUE;
            float maxPrice = Float.MIN_VALUE;
            boolean hasValidData = false;
            
            for (float p : dayData.lowPrices) {
                if (p > 0) {
                    minPrice = Math.min(minPrice, p);
                    hasValidData = true;
                }
            }
            for (float p : dayData.highPrices) {
                if (p > 0) {
                    maxPrice = Math.max(maxPrice, p);
                    hasValidData = true;
                }
            }

            if (!hasValidData) {
                g.setColor(Color.WHITE);
                g.drawString("No Valid Price Data (> 0)", getWidth() / 2, getHeight() / 2);
                return;
            }

            // Add some padding to price range
            float priceRange = maxPrice - minPrice;
            if (priceRange == 0) priceRange = 1;
            minPrice -= priceRange * 0.05;
            maxPrice += priceRange * 0.05;
            priceRange = maxPrice - minPrice;

            int totalMinutes = dayData.closePrices.size();
            double candleWidth = (double) panelWidth / totalMinutes;

            // Draw Candles
            for (int i = 0; i < totalMinutes; i++) {
                float open = dayData.openPrices.get(i);
                float close = dayData.closePrices.get(i);
                float high = dayData.highPrices.get(i);
                float low = dayData.lowPrices.get(i);

                // Skip invalid candles
                if (close <= 0 || open <= 0 || high <= 0 || low <= 0) {
                    continue;
                }

                double x = xOffset + (i * candleWidth);
                
                // Y-coordinates (inverted because 0 is top)
                double yHigh = yOffset + panelHeight - ((high - minPrice) / priceRange * panelHeight);
                double yLow = yOffset + panelHeight - ((low - minPrice) / priceRange * panelHeight);
                double yOpen = yOffset + panelHeight - ((open - minPrice) / priceRange * panelHeight);
                double yClose = yOffset + panelHeight - ((close - minPrice) / priceRange * panelHeight);

                // Draw Wick
                g2d.setColor(Color.LIGHT_GRAY);
                g2d.drawLine((int) (x + candleWidth / 2), (int) yHigh, (int) (x + candleWidth / 2), (int) yLow);

                // Draw Body
                if (close > open) {
                    g2d.setColor(Color.GREEN);
                    g2d.fillRect((int) x, (int) yClose, (int) Math.max(1, candleWidth - 1), (int) (yOpen - yClose));
                } else {
                    g2d.setColor(Color.RED);
                    g2d.fillRect((int) x, (int) yOpen, (int) Math.max(1, candleWidth - 1), (int) (yClose - yOpen));
                }
            }

            // Draw Trade Markers
            if (entryIndex >= 0 && entryIndex < totalMinutes) {
                drawMarker(g2d, entryIndex, candleWidth, xOffset, yOffset, panelHeight, Color.BLUE, "Entry");
            }

            if (exitIndex >= 0 && exitIndex < totalMinutes) {
                drawMarker(g2d, exitIndex, candleWidth, xOffset, yOffset, panelHeight, Color.ORANGE, "Exit");
            }
            
            // Draw Info Text
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Monospaced", Font.BOLD, 14));
            
            String entryTime = (entryIndex >= 0 && entryIndex < dayData.minutes.size()) ? formatTime(dayData.minutes.get(entryIndex)) : "N/A";
            String exitTime = (exitIndex >= 0 && exitIndex < dayData.minutes.size()) ? formatTime(dayData.minutes.get(exitIndex)) : "N/A";
            String direction = predictedChange > 0 ? "LONG" : "SHORT";
            
            float marketChange = 0;
            float actualOutcome = 0;
            
            if (entryIndex >= 0 && exitIndex >= 0 && entryIndex < dayData.closePrices.size() && exitIndex < dayData.closePrices.size()) {
                float entryPrice = dayData.closePrices.get(entryIndex);
                float exitPrice = dayData.closePrices.get(exitIndex);
                
                // Calculate market movement in cents
                marketChange = (exitPrice - entryPrice) * 100.0f;
                
                // Calculate P/L based on direction
                if (predictedChange > 0) { // LONG
                    actualOutcome = marketChange;
                } else { // SHORT
                    actualOutcome = -marketChange;
                }
            }
            
            String info = String.format("Date: %s | Time: %s -> %s | %s | Pred: %.2f | Market: %.2f | P/L: %.2f | Count: %.0f", 
                    dayData.date.toString(), entryTime, exitTime, direction, predictedChange, marketChange, actualOutcome, patternCount);
            g2d.drawString(info, 20, 20);
        }

        private void drawMarker(Graphics2D g2d, int index, double candleWidth, int xOffset, int yOffset, int panelHeight, Color color, String label) {
            double x = xOffset + (index * candleWidth) + (candleWidth / 2);
            g2d.setColor(color);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawLine((int) x, yOffset, (int) x, yOffset + panelHeight);
            g2d.drawString(label, (int) x + 5, yOffset + 15);
        }
        
        private String formatTime(int minutesFromOpen) {
            // Market opens at 9:30 AM
            int totalMinutes = 9 * 60 + 30 + minutesFromOpen;
            int hour = totalMinutes / 60;
            int minute = totalMinutes % 60;
            return String.format("%02d:%02d", hour, minute);
        }
    }
}
