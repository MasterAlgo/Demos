package optimizer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class OptimizationPanel extends JPanel {

    private final JButton startButton, stopButton;
    private final JToggleButton pauseButton;
    private final JTable resultsTable;
    private final DefaultTableModel tableModel;
    private final JLabel statusLabel;

    private final OptimizerController controller;

    public OptimizationPanel() {
        super(new BorderLayout(10, 10));
        this.controller = new OptimizerController();
        this.controller.setPanel(this);

        // --- Top: Controls ---
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        pauseButton = new JToggleButton("Pause");
        
        stopButton.setEnabled(false);
        pauseButton.setEnabled(false);

        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        controlPanel.add(pauseButton);
        
        statusLabel = new JLabel("Status: Idle");
        controlPanel.add(statusLabel);

        add(controlPanel, BorderLayout.NORTH);

        // --- Center: Results Table ---
        String[] columnNames = {"Run", "Parameters", "Sharpe Ratio", "Max Drawdown", "Profit Factor"};
        tableModel = new DefaultTableModel(columnNames, 0);
        resultsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        add(scrollPane, BorderLayout.CENTER);

        // --- Action Listeners ---
        startButton.addActionListener(e -> {
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            pauseButton.setEnabled(true);
            updateStatus("Status: Starting...");
            controller.startOptimization();
        });

        stopButton.addActionListener(e -> {
            controller.stopOptimization();
            // UI state will be updated in onOptimizationFinished
        });

        pauseButton.addActionListener(e -> {
            boolean isPaused = pauseButton.isSelected();
            controller.pauseOptimization(isPaused);
            updateStatus(isPaused ? "Status: Paused" : "Status: Running...");
        });
    }

    public void clearResults() {
        tableModel.setRowCount(0);
    }

    public void addResult(OptimizationResult result) {
        tableModel.addRow(result.toTableRow());
    }
    
    public void updateStatus(String status) {
        statusLabel.setText(status);
    }

    public void onOptimizationFinished() {
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        pauseButton.setSelected(false);
        pauseButton.setEnabled(false);
        updateStatus("Status: Finished");
    }
}
