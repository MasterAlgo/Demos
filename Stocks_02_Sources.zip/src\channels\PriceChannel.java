package channels;

import globals.Globals;

public abstract class PriceChannel extends Channel {

    private final int referencePoint;
    private final int granularity;

    public PriceChannel(String name) {
        super(name);
        // Initialize configuration once in the constructor
        this.referencePoint = getConfigInt("OHLC_referencePoint", -1);
        this.granularity = getConfigInt("OHLC_priceGranularity", 100);
    }

    // This method will be implemented by the concrete subclasses (OpenChannel, CloseChannel, etc.)
    protected abstract float getPrice(DailyData day, int index);

    @Override
    public boolean populateWindow(DailyData currentDay, int minuteIndex, int windowSize, int[] targetArray) {
        // Bounds Check for history and window size
        // The reference point is relative to the START of the window (minuteIndex)
        int refMinuteIndex = minuteIndex + referencePoint;
        
        if (refMinuteIndex < 0) {
            return false;
        }
        if (minuteIndex + windowSize > currentDay.closePrices.size()) {
            return false;
        }
        
        // Check if the reference price itself is missing
        if (currentDay.isMissing.get(refMinuteIndex)) {
            // If the anchor for the whole frame is missing, the frame is invalid.
            return false;
        }

        float refPrice = getPrice(currentDay, refMinuteIndex);

        // Populate the target array
        for (int i = 0; i < windowSize; i++) {
            int currentMinute = minuteIndex + i;

            // Check if the current minute data is missing
            if (currentDay.isMissing.get(currentMinute)) {
                targetArray[i] = Globals.MISSING_TOKEN;
                continue;
            }

            float currentPrice = getPrice(currentDay, currentMinute);
            float delta = currentPrice - refPrice;

            targetArray[i] = Math.round(delta * granularity);
        }

        return true;
    }
}
