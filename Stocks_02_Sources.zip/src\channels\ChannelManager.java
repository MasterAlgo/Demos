package channels;

import globals.AppConfig;
import globals.Globals;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Manages the lifecycle of channel objects and serves as the primary source 
 * for generating input matrices for the trading engine using an on-the-fly model.
 */
public class ChannelManager {

    // Reusable matrix to avoid garbage collection pressure
    private int[][] matrix;

    /**
     * Reads active channel names from AppConfig and instantiates the corresponding
     * concrete Channel objects, storing them in AppConfig.activeChannels.
     * This is called ONCE before the main trading loop.
     */
    public void initialize() {
        AppConfig.activeChannels.clear();
        
        for (String name : AppConfig.activeChannelNames) {
            switch (name) {
                case "Open":
                    AppConfig.activeChannels.put(name, new OpenChannel());
                    break;
                case "High":
                    AppConfig.activeChannels.put(name, new HighChannel());
                    break;
                case "Low":
                    AppConfig.activeChannels.put(name, new LowChannel());
                    break;
                case "Close":
                    AppConfig.activeChannels.put(name, new CloseChannel());
                    break;
                case "Volume":
                    AppConfig.activeChannels.put(name, new VolumeChannel());
                    break;
                case "Hour of Day":
                    AppConfig.activeChannels.put(name, new HourOfDayChannel());
                    break;
                case "Moving Average":
                    AppConfig.activeChannels.put(name, new MovingAverageChannel());
                    break;
                // Add other channels here in the future
            }
        }
        
        // Initialize the reusable matrix
        int windowSize = AppConfig.TRAINING_WINDOW_SIZE;
        if (windowSize <= 0) windowSize = 10;
        
        if (!AppConfig.activeChannels.isEmpty()) {
            this.matrix = new int[AppConfig.activeChannels.size()][windowSize];
        } else {
            this.matrix = new int[0][0];
        }
        
        System.out.println("ChannelManager: Initialized " + AppConfig.activeChannels.size() + " channels.");
        
        // Print the list of initialized channels to the console and update status
        String channelList = String.join(", ", AppConfig.activeChannels.keySet());
        Globals.STATE = "Initialized: " + channelList;
    }

    /**
     * Constructs and returns the input matrix for the neural network for a specific point in time.
     * This method is called REPEATEDLY inside the DataController's main loop.
     *
     * @param allData The complete raw dataset.
     * @param dayIndex The index of the current day in allData.
     * @param minuteIndex The index of the current minute within the current day.
     * @return A 2D integer array (matrix) where:
     *         - Rows correspond to the active channels.
     *         - Columns correspond to the time steps in the window (TRAINING_WINDOW_SIZE).
     *         Returns null if the requested matrix is invalid for the given time point.
     */
    public int[][] getCombinedMatrix(List<DailyData> allData, int dayIndex, int minuteIndex) {
        int windowSize = AppConfig.TRAINING_WINDOW_SIZE;
        if (windowSize <= 0) windowSize = 10;

        Collection<Channel> channels = AppConfig.activeChannels.values();
        if (channels.isEmpty()) {
            return new int[0][0];
        }
        
        // Get the current day object once
        DailyData currentDay = allData.get(dayIndex);

        int channelIndex = 0;
        for (Channel channel : channels) {
            // Pass the target array (row of the matrix) directly to the channel
            // This avoids allocating a new int[] for every window
            boolean success = channel.populateWindow(currentDay, minuteIndex, windowSize, matrix[channelIndex]);

            if (!success) {
                // If any channel fails (e.g., bounds check), the entire matrix is invalid
                return null;
            }
            
            channelIndex++;
        }

        return matrix;
    }

    /**
     * Provides access to the currently active channel instances.
     * @return A collection of the active Channel objects.
     */
    public Collection<Channel> getActiveChannels() {
        return AppConfig.activeChannels.values();
    }
}
