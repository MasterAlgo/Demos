package trader;

import globals.AppConfig;
import globals.Globals;
import channels.DailyData;
import optimizer.TradeInfo;
import ui.IntradayChartFrame;
import ui.ProfitChartFrame;
import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.List;

public class InferenceEngine {

    private float[] accumulatedPrediction;
    private float totalWeight = 0;
    private boolean isInitialized = false;
    
    // Statistics
    private int tradeCount = 0;
    private float accumulatedOutcome = 0;

    public InferenceEngine() {
        // Constructor
    }

    private void initialize() {
        // Prediction window + 1 (for count)
        int size = AppConfig.PREDICTION_WINDOW_SIZE + 1;
        this.accumulatedPrediction = new float[size];
        isInitialized = true;
    }

    /**
     * Resets only the prediction buffers for the current inference window.
     * Should be called before processing a new set of patterns for a specific time step.
     */
    public void resetPrediction() {
        if (!isInitialized) initialize();
        for (int i = 0; i < accumulatedPrediction.length; i++) {
            accumulatedPrediction[i] = 0;
        }
        totalWeight = 0;
    }

    /**
     * Resets the entire simulation statistics (trade count, accumulated profit).
     * Should be called at the start of a new backtest run.
     */
    public void resetSimulation() {
        if (!isInitialized) initialize();
        
        // Reset prediction buffers
        resetPrediction();
        
        // Reset stats
        tradeCount = 0;
        accumulatedOutcome = 0;
        if (Globals.profitChartFrame != null) {
            Globals.profitChartFrame.reset();
        }
    }

    public void submit(int[] accumulated, int actualTokenCount, int[] currentSequence) {
        if (!isInitialized) initialize();
        int count = accumulated[accumulated.length - 1];

        // --- Dynamic Min Pattern Count ---
        double dynamicThreshold = Globals.MIN_PATTERN_COUNT;
        if (Globals.ANN_SIZE > 0 && Globals.REFERENCE_ANN_SIZE > 0) {
            double sizeRatio = (double) Globals.ANN_SIZE / Globals.REFERENCE_ANN_SIZE;
            if (sizeRatio > 0) { // Avoid log of zero or negative
                switch (Globals.MIN_PATTERN_COUNT_SCALING) {
                    case "LINEAR":
                        dynamicThreshold = Globals.MIN_PATTERN_COUNT * sizeRatio;
                        break;
                    case "LOG2":
                        dynamicThreshold = Globals.MIN_PATTERN_COUNT * (Math.log(sizeRatio) / Math.log(2) + 1);
                        break;
                    case "LN":
                        dynamicThreshold = Globals.MIN_PATTERN_COUNT * (Math.log(sizeRatio) + 1);
                        break;
                    case "LOG10":
                        dynamicThreshold = Globals.MIN_PATTERN_COUNT * (Math.log10(sizeRatio) + 1);
                        break;
                    case "STATIC":
                    default:
                        // Use the static value
                        break;
                }
            }
        }
        // Ensure threshold doesn't fall below the base
        dynamicThreshold = Math.max(Globals.MIN_PATTERN_COUNT, dynamicThreshold);

        // Filter out low-count patterns using the dynamic threshold
        if (count < dynamicThreshold) {
            return;
        }

        // Apply Damped Average: Value = Sum / (Count + K)
        // This reduces the impact of low-count patterns (noise).
        int k = Globals.K_FACTOR;
        
        // Weighting Factor: Specificity^2
        // Patterns with more actual tokens are significantly more trusted.
        float weight = (float) (actualTokenCount * actualTokenCount);
        
        for (int i = 0; i < accumulatedPrediction.length - 1; i++) {
            float dampedValue = (float) accumulated[i] / (count + k);
            
            // Debug: Check for suspicious values
            if (Math.abs(dampedValue) > 50.0f) {
                String msg = String.format("DEBUG: High Damped Value: %.2f | Count: %d | AccSum: %d | Weight: %.0f | ActualTokens: %d", 
                        dampedValue, count, accumulated[i], weight, actualTokenCount);
                if (Globals.logArea != null) {
                    SwingUtilities.invokeLater(() -> Globals.logArea.append(msg + "\n"));
                }
            }
            
            // Apply the weight
            accumulatedPrediction[i] += (dampedValue * weight);
        }
        
        // Accumulate the count as well (last element)
        accumulatedPrediction[accumulatedPrediction.length - 1] += count;
        
        // Track total weight for normalization
        totalWeight += weight;
    }

    public float[] finalizePrediction() {
        if (!isInitialized) return null;
        
        float[] result = new float[accumulatedPrediction.length];

        if (!Globals.HEURISTIC_ENABLED) {
            // DEBUG_PRINT START
            // System.out.print("DEBUG: InferenceEngine.finalizePrediction accumulatedPrediction: ");
            // for (float val : accumulatedPrediction) {
            //     System.out.printf("%.2f ", val);
            // }
            // System.out.println();

            // if (Globals.currentDayIndex >= 0 && Globals.currentDayIndex < Globals.allData.size()) {
            //     DailyData dd = Globals.allData.get(Globals.currentDayIndex);
            //     int idx = Globals.currentMinuteIndex;
            //     if (idx >= 0 && idx < dd.minutes.size()) {
            //          // Format: "01/02/1998,09:46,26.487,26.534,26.487,26.503,40347"
            //          int totalMinutes = 9 * 60 + 30 + dd.minutes.get(idx);
            //          int hour = totalMinutes / 60;
            //          int minute = totalMinutes % 60;
            //          String timeStr = String.format("%02d:%02d", hour, minute);
                     
            //          String dateStr = String.format("%02d/%02d/%d", dd.date.getDayOfMonth(), dd.date.getMonthValue(), dd.date.getYear());

            //          System.out.printf("DEBUG: Data Line: %s,%s,%.3f,%.3f,%.3f,%.3f,%d",
            //                 dateStr, timeStr,
            //                 dd.openPrices.get(idx), dd.highPrices.get(idx), dd.lowPrices.get(idx), dd.closePrices.get(idx),
            //                 dd.volumes.get(idx));
                     
            //          if (dd.isMissing.get(idx)) {
            //              System.out.print(" (missing - thus engineered)");
            //          }
            //          System.out.println();
            //     }
            // }
            // DEBUG_PRINT END
            
            // Avoid division by zero
            if (totalWeight == 0) {
                return result; // Returns all zeros
            }
            
            // Normalize the accumulated prediction by the total weight
            for (int i = 0; i < accumulatedPrediction.length - 1; i++) {
                result[i] = accumulatedPrediction[i] / totalWeight;
            }
            
            // Pass through the raw count (last element) without normalization
            result[result.length - 1] = accumulatedPrediction[accumulatedPrediction.length - 1];
            
            // Find the best exit point (max absolute deviation)
            int bestIndex = -1;
            float maxDeviation = 0;
            
            for (int i = 0; i < result.length - 1; i++) {
                float absVal = Math.abs(result[i]);
                if (absVal > maxDeviation) {
                    maxDeviation = absVal;
                    bestIndex = i;
                }
            }
            
            // Check if the best deviation exceeds the threshold
            if (bestIndex != -1 && maxDeviation > Globals.TRADE_THRESHOLD) {
                trade(result, bestIndex);
            }
        } else {
            // Heuristic logic will go here
            float positiveSentiment = 0;
            float negativeSentiment = 0;

            // Avoid division by zero
            if (totalWeight == 0) {
                return result; // Returns all zeros
            }

            // Normalize the accumulated prediction by the total weight
            for (int i = 0; i < accumulatedPrediction.length - 1; i++) {
                result[i] = accumulatedPrediction[i] / totalWeight;
            }
            
            // Pass through the raw count (last element) without normalization
            result[result.length - 1] = accumulatedPrediction[accumulatedPrediction.length - 1];

            // Calculate sentiment from the normalized predictions
            for (int i = 0; i < result.length - 1; i++) { // Exclude the last element (count)
                if (result[i] > 0) {
                    positiveSentiment += result[i];
                } else if (result[i] < 0) {
                    negativeSentiment += result[i];
                }
            }
            
            // Check if one sentiment prevails and exceeds the threshold
            if (positiveSentiment > Math.abs(negativeSentiment) && positiveSentiment > Globals.SENTIMENT_THRESHOLD) {
                // Positive sentiment prevails
                int bestIndex = -1;
                float maxValue = 0;
                
                for (int i = 0; i < result.length - 1; i++) {
                    if (result[i] > maxValue) {
                        maxValue = result[i];
                        bestIndex = i;
                    }
                }
                
                if (bestIndex != -1) {
                    trade(result, bestIndex);
                }
                
            } else if (Math.abs(negativeSentiment) > positiveSentiment && Math.abs(negativeSentiment) > Globals.SENTIMENT_THRESHOLD) {
                // Negative sentiment prevails
                int bestIndex = -1;
                float minValue = 0;
                
                for (int i = 0; i < result.length - 1; i++) {
                    if (result[i] < minValue) {
                        minValue = result[i];
                        bestIndex = i;
                    }
                }
                
                if (bestIndex != -1) {
                    trade(result, bestIndex);
                }
            }
        }
        
        return result;
    }
    
    public void trade(float[] prediction, int bestIndex) {
        // 1. Get Context
        if (Globals.currentDayIndex < 0 || Globals.currentDayIndex >= Globals.allData.size()) return;
        DailyData currentDay = Globals.allData.get(Globals.currentDayIndex);
        
        // Correct Entry Index: The decision is made at the END of the training window.
        // currentMinuteIndex is the START of the window.
        int entryIndex = Globals.currentMinuteIndex + AppConfig.TRAINING_WINDOW_SIZE - 1;
        int exitIndex = entryIndex + bestIndex + 1;
        float predictedValue = prediction[bestIndex];
        float patternCount = prediction[prediction.length - 1];
        
        // Calculate Outcome
        float entryPrice = currentDay.closePrices.get(entryIndex);
        float exitPrice = currentDay.closePrices.get(exitIndex);
        float marketChange = (exitPrice - entryPrice) * 100.0f; // in cents
        float actualOutcome = (predictedValue > 0) ? marketChange : -marketChange;
        
        // Update Stats
        tradeCount++;
        accumulatedOutcome += actualOutcome;
        
        String direction = predictedValue > 0 ? "LONG" : "SHORT";

        // Console Printout
        String consoleMsg = String.format("Trade #%d | %-5s | Date: %s | Time: %s -> %s | Count: %.0f | Price: %.3f -> %.3f | Pred: %.2f | Actual: %.2f | Accum: %.2f",
                tradeCount,
                direction,
                currentDay.date.toString(),
                formatTime(entryIndex),
                formatTime(exitIndex),
                patternCount,
                entryPrice,
                exitPrice,
                predictedValue,
                actualOutcome,
                accumulatedOutcome);
        System.out.println(consoleMsg);
        
        // 2. Log Trade (UI)
        if (Globals.EXTENDED_LOGGING) {
            String logMsg = String.format("TRADE: Day %s | Min %d (%s) | Pred: %.2f cents @ T+%d | %s", 
                    currentDay.date.toString(), entryIndex, formatTime(entryIndex), predictedValue, (bestIndex + 1), direction);
            
            if (Globals.logArea != null) {
                SwingUtilities.invokeLater(() -> {
                    Globals.logArea.append(logMsg + "\n");
                    
                    // Dump Detailed Context
                    StringBuilder sb = new StringBuilder("DEBUG: Trade Context:\n");
                    sb.append("Date,Time,Open,High,Low,Close,Volume\n");
                    
                    // Show Training Window + Prediction Window
                    int start = Math.max(0, Globals.currentMinuteIndex); // Start of training window
                    int end = Math.min(currentDay.closePrices.size(), exitIndex + 1); // End of prediction window
                    
                    for (int i = start; i < end; i++) {
                        String timeStr = formatTime(i);
                        // Format: Date,Time,Open,High,Low,Close,Volume
                        String line = String.format("%s,%s,%.3f,%.3f,%.3f,%.3f,%d",
                                currentDay.date.toString(),
                                timeStr,
                                currentDay.openPrices.get(i),
                                currentDay.highPrices.get(i),
                                currentDay.lowPrices.get(i),
                                currentDay.closePrices.get(i),
                                currentDay.volumes.get(i));
                        
                        sb.append(line);
                        
                        if (i == entryIndex) {
                            sb.append(" <--- ENTRY (").append(direction).append(")");
                        } else if (i == exitIndex) {
                            sb.append(" <--- EXIT *");
                        }
                        sb.append("\n");
                    }
                    Globals.logArea.append(sb.toString() + "\n");
                    
                    Globals.logArea.setCaretPosition(Globals.logArea.getDocument().getLength());
                });
            }
        }
        
        // 3. Update Chart
        if (Globals.SHOW_INTRADAY_CHART) {
            SwingUtilities.invokeLater(() -> {
                if (Globals.chartFrame == null) {
                    Globals.chartFrame = new IntradayChartFrame();
                }
                Globals.chartFrame.updateChart(currentDay, entryIndex, exitIndex, predictedValue, patternCount);
            });
        }
        
        // 4. Update Profit Chart
        if (Globals.SHOW_PROFIT_CHART) {
            SwingUtilities.invokeLater(() -> {
                if (Globals.profitChartFrame == null) {
                    Globals.profitChartFrame = new ProfitChartFrame();
                }
                float currentPrice = currentDay.closePrices.get(entryIndex);
                Globals.profitChartFrame.addDataPoint(accumulatedOutcome, currentPrice);
            });
        }
        
        // 5. Request Pause if enabled
        if (Globals.PAUSE_ON_TRADE) {
            Globals.REQUEST_PAUSE = true;
        }

        // 6. Notify Optimizer
        if (Globals.optimizerController != null && Globals.optimizerController.isRunning()) {
            Globals.optimizerController.onTrade(new TradeInfo(
                tradeCount,
                direction,
                currentDay.date.toString(),
                formatTime(entryIndex),
                formatTime(exitIndex),
                entryPrice,
                exitPrice,
                predictedValue,
                actualOutcome,
                accumulatedOutcome
            ));
        }
    }
    
    private String formatTime(int minutesFromOpen) {
        // Market opens at 9:30 AM
        int totalMinutes = 9 * 60 + 30 + minutesFromOpen;
        int hour = totalMinutes / 60;
        int minute = totalMinutes % 60;
        return String.format("%02d:%02d", hour, minute);
    }
}
