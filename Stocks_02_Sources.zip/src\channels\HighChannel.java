package channels;

public class HighChannel extends PriceChannel {
    public HighChannel() {
        super("High");
    }

    @Override
    protected float getPrice(DailyData day, int index) {
        return day.highPrices.get(index);
    }
}
