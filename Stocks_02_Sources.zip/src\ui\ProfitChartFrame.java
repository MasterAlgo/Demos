package ui;

import globals.Globals;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ProfitChartFrame extends JFrame {

    private final ProfitPanel profitPanel;
    private JToggleButton buyAndHoldToggleButton;

    public ProfitChartFrame() {
        setTitle("Accumulated Profit Chart");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLocationRelativeTo(null);

        profitPanel = new ProfitPanel();
        
        // Create a panel for the chart and controls
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.add(profitPanel, BorderLayout.CENTER);

        // Add toggle button for Buy & Hold
        buyAndHoldToggleButton = new JToggleButton("Show Buy & Hold");
        buyAndHoldToggleButton.addActionListener(e -> {
            profitPanel.setShowBuyAndHold(buyAndHoldToggleButton.isSelected());
            profitPanel.repaint();
        });
        
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.add(buyAndHoldToggleButton);
        contentPanel.add(controlPanel, BorderLayout.NORTH);

        add(contentPanel);
    }

    public void addDataPoint(float accumulatedProfit, float currentPrice) {
        SwingUtilities.invokeLater(() -> {
            profitPanel.addDataPoint(accumulatedProfit, currentPrice);
            if (!isVisible()) {
                setVisible(true);
            }
            repaint();
        });
    }
    
    public void reset() {
        SwingUtilities.invokeLater(() -> {
            profitPanel.reset();
            repaint();
        });
    }

    private static class ProfitPanel extends JPanel {
        private final List<Float> profitHistory = new ArrayList<>();
        private final List<Float> buyAndHoldHistory = new ArrayList<>();
        private boolean showBuyAndHold = false;

        public ProfitPanel() {
            setBackground(Color.BLACK);
            // Add initial 0 point for profit history
            profitHistory.add(0.0f);
        }

        public void addDataPoint(float profit, float currentPrice) {
            profitHistory.add(profit);
            // Convert B&H profit to cents to match the trading profit's unit
            buyAndHoldHistory.add((currentPrice - Globals.startGlobalPrice) * 100.0f);
        }
        
        public void reset() {
            profitHistory.clear();
            profitHistory.add(0.0f);
            buyAndHoldHistory.clear();
        }

        public void setShowBuyAndHold(boolean showBuyAndHold) {
            this.showBuyAndHold = showBuyAndHold;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            if (profitHistory.isEmpty()) return;

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();
            int padding = 40;

            // Find Min/Max for both charts
            float minVal = 0; // Always include 0
            float maxVal = 0;
            
            for (float val : profitHistory) {
                minVal = Math.min(minVal, val);
                maxVal = Math.max(maxVal, val);
            }
            
            if (showBuyAndHold && !buyAndHoldHistory.isEmpty()) {
                for (float val : buyAndHoldHistory) {
                    minVal = Math.min(minVal, val);
                    maxVal = Math.max(maxVal, val);
                }
            }

            // Add some margin
            float range = maxVal - minVal;
            if (range == 0) range = 10; // Default range if flat
            
            // Calculate scale factors
            double yScale = (double) (height - 2 * padding) / range;
            
            // Calculate Zero Line Y
            int zeroY = (int) (height - padding - (0 - minVal) * yScale);

            // Draw Zero Line
            g2d.setColor(Color.GRAY);
            g2d.drawLine(padding, zeroY, width - padding, zeroY);
            g2d.drawString("0.00", 5, zeroY + 5);

            // Draw Trading Profit Chart
            drawChartLine(g2d, profitHistory, width, height, padding, minVal, yScale, zeroY, true);

            // Draw Buy & Hold Chart if enabled
            if (showBuyAndHold && !buyAndHoldHistory.isEmpty()) {
                drawChartLine(g2d, buyAndHoldHistory, width, height, padding, minVal, yScale, zeroY, false);
            }
            
            // Draw current value label for Trading Profit
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Monospaced", Font.BOLD, 14));
            String info = String.format("Trading Profit: %.2f cents", profitHistory.get(profitHistory.size() - 1));
            g2d.drawString(info, padding, 20);

            // Draw current value label for Buy & Hold if enabled
            if (showBuyAndHold && !buyAndHoldHistory.isEmpty()) {
                String bnhInfo = String.format("Buy & Hold Profit: %.2f cents", buyAndHoldHistory.get(buyAndHoldHistory.size() - 1));
                g2d.drawString(bnhInfo, padding, 40); // Below trading profit info
            }
        }

        private void drawChartLine(Graphics2D g2d, List<Float> history, int width, int height, int padding, float minVal, double yScale, int zeroY, boolean coloredByProfit) {
            if (history.size() < 2) return; // Need at least two points to draw a line

            double xStep = (double) (width - 2 * padding) / (Math.max(1, history.size() - 1));

            for (int i = 0; i < history.size() - 1; i++) {
                float val1 = history.get(i);
                float val2 = history.get(i + 1);

                int x1 = padding + (int) (i * xStep);
                int y1 = (int) (height - padding - (val1 - minVal) * yScale);
                
                int x2 = padding + (int) ((i + 1) * xStep);
                int y2 = (int) (height - padding - (val2 - minVal) * yScale);

                if (coloredByProfit) {
                    // Check for zero crossing
                    if ((val1 > 0 && val2 < 0) || (val1 < 0 && val2 > 0)) {
                        // Calculate intersection point
                        float fraction = Math.abs(val1) / (Math.abs(val1) + Math.abs(val2));
                        int xCross = x1 + (int) ((x2 - x1) * fraction);
                        int yCross = zeroY;

                        // Draw first segment
                        g2d.setColor(val1 >= 0 ? Color.GREEN : Color.RED);
                        g2d.setStroke(new BasicStroke(2));
                        g2d.drawLine(x1, y1, xCross, yCross);

                        // Draw second segment
                        g2d.setColor(val2 >= 0 ? Color.GREEN : Color.RED);
                        g2d.drawLine(xCross, yCross, x2, y2);
                    } else {
                        // No crossing, single color
                        if (val1 >= 0 && val2 >= 0) g2d.setColor(Color.GREEN);
                        else g2d.setColor(Color.RED);
                        
                        g2d.setStroke(new BasicStroke(2));
                        g2d.drawLine(x1, y1, x2, y2);
                    }
                } else {
                    // For Buy & Hold, draw in white
                    g2d.setColor(Color.WHITE);
                    g2d.setStroke(new BasicStroke(1)); // Thinner line for B&H
                    g2d.drawLine(x1, y1, x2, y2);
                }
            }
        }
    }
}
