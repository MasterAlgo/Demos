package optimizer;

public class TradeInfo {
    public final int tradeIndex;
    public final String direction;
    public final String date;
    public final String entryTime;
    public final String exitTime;
    public final float entryPrice;
    public final float exitPrice;
    public final float predictedValue;
    public final float actualOutcome;
    public final float accumulatedOutcome;

    public TradeInfo(int tradeIndex, String direction, String date, String entryTime, String exitTime,
                     float entryPrice, float exitPrice, float predictedValue, float actualOutcome, float accumulatedOutcome) {
        this.tradeIndex = tradeIndex;
        this.direction = direction;
        this.date = date;
        this.entryTime = entryTime;
        this.exitTime = exitTime;
        this.entryPrice = entryPrice;
        this.exitPrice = exitPrice;
        this.predictedValue = predictedValue;
        this.actualOutcome = actualOutcome;
        this.accumulatedOutcome = accumulatedOutcome;
    }
}
