package globals;

import channels.DailyData;
//import containers.PatternContainer_retired;
import containers.PatternEngine;
import containers.TokenDictionary;
// import containers.Tokenizer_retired;  // retired
import containers.Tokenizer;
import optimizer.OptimizerController;
import trader.InferenceEngine;
import ui.AnnParamsPanel;
import ui.IntradayChartFrame; // Will be created soon
import ui.ProfitChartFrame;
import javax.swing.JTextArea;
import java.util.List;

public class Globals {
    public static long ANN_SIZE = 0; // Initial value: 150 MB
    public static String STATE = "idling...";

    public static List<DailyData> allData;
    
    public static final int MISSING_TOKEN = Integer.MIN_VALUE;
    public static float REMOVE_THRESHOLD_PERCENT = 0.30f;

    // --- Buy and Hold Benchmark Metrics ---
    public static double buyAndHoldProfit1k = 0.0;
    public static double buyAndHoldProfit2k = 0.0;
    public static double buyAndHoldProfit3k = 0.0;

    // --- Global Containers ---
    //public static Tokenizer_retired tokenizer;  // retired
    public static Tokenizer tokenizer;
    public static TokenDictionary tokenDictionary;
    //public static PatternContainer_retired patternContainer;  //retired
    public static PatternEngine patternEngine;
    public static InferenceEngine inferenceEngine;
    public static OptimizerController optimizerController;
    
    // --- Context Variables ---
    public static int currentDayIndex = -1;
    public static int currentMinuteIndex = -1;
    
    // --- Inference Parameters ---
    // K_FACTOR: Smoothing factor for damped average calculation.
    // Formula: Value = Sum / (Count + K_FACTOR)
    // Higher K means more conservative predictions (requires more evidence).
    public static int K_FACTOR = 5; 
    
    // MIN_PATTERN_COUNT: Minimum number of times a pattern must have been seen to be considered.
    // Filters out statistically insignificant patterns.
    public static int MIN_PATTERN_COUNT = 10;
    
    // TRADE_THRESHOLD: The minimum predicted price change (in cents) required to trigger a trade.
    // A trade is considered if a predicted value's absolute magnitude exceeds this threshold.
    public static float TRADE_THRESHOLD = 5.0f;
    
    // --- UI References ---
    public static AnnParamsPanel annParamsPanel;
    public static JTextArea logArea; // Direct access to the log area
    public static IntradayChartFrame chartFrame; // Singleton instance of the chart frame
    public static ProfitChartFrame profitChartFrame; // Singleton instance of the profit chart frame
    
    // --- Control Flags ---
    public static boolean PAUSE_ON_TRADE = false;
    public static volatile boolean REQUEST_PAUSE = false; // Signal from Engine to Controller
    
    // --- Display/Log Flags ---
    public static boolean EXTENDED_LOGGING = true;
    public static boolean SHOW_INTRADAY_CHART = true;
    public static boolean SHOW_PROFIT_CHART = true;

    // --- Heuristic Flags ---
    public static boolean HEURISTIC_ENABLED = false;
    public static float SENTIMENT_THRESHOLD = 20.0f;

    // --- Dynamic Min Pattern Count ---
    public static String MIN_PATTERN_COUNT_SCALING = "STATIC";
    public static long REFERENCE_ANN_SIZE = 50_000_000L;
    public static float startGlobalPrice  = -1;                   // to remember very very open price of the dataset
}
