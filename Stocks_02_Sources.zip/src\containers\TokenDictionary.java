package containers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TokenDictionary {

    private final Map<List<Integer>, Integer> tokenToId;
    private final List<List<Integer>> idToToken;

    public TokenDictionary() {
        this.tokenToId = new HashMap<>();
        this.idToToken = new ArrayList<>();
        // Reserve index 0 for a skip/null token, so actual tokens start from ID 1.
        this.idToToken.add(null);
    }

    public synchronized int getOrAdd(int[] token) {
        List<Integer> tokenList = new ArrayList<>(token.length);
        for (int i : token) {
            tokenList.add(i);
        }

        Integer id = tokenToId.get(tokenList);
        if (id != null) {
            return id;
        } else {
            int newId = idToToken.size();
            // Store an immutable copy or just the list itself
            idToToken.add(tokenList);
            tokenToId.put(tokenList, newId);
            return newId;
        }
    }

    public synchronized int[] getToken(int id) {
        if (id > 0 && id < idToToken.size()) {
            List<Integer> tokenList = idToToken.get(id);
            if (tokenList == null) return null;

            int[] result = new int[tokenList.size()];
            for (int i = 0; i < tokenList.size(); i++) {
                result[i] = tokenList.get(i);
            }
            return result;
        }
        return null;
    }
    
    public int getSize() {
        return idToToken.size();
    }
}
