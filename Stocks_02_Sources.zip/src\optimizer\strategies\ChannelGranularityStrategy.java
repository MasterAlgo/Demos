package optimizer.strategies;

import globals.AppConfig;
import utilities.PersistenceUtility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ChannelGranularityStrategy {

    public String getName() {
        return "Channel and Granularity";
    }

    public List<Map<String, String>> generateCombinations() {
        List<Map<String, String>> combinations = new ArrayList<>();

        // --- Define Parameters to Test ---
        List<String> granularities = Arrays.asList("5", "10", "15");
        List<List<String>> channelSets = Arrays.asList(
            Arrays.asList("Open", "Volume", "Hour of Day"),
            Arrays.asList("Close", "Volume", "Hour of Day"),
            Arrays.asList("Open", "Close", "Volume", "Hour of Day")
        );

        // --- Generate Combinations ---
        for (String granularity : granularities) {
            for (List<String> channelSet : channelSets) {
                Map<String, String> params = new LinkedHashMap<>();
                params.put("Granularity", granularity);
                params.put("Channels", String.join(",", channelSet));
                combinations.add(params);
            }
        }
        return combinations;
    }

    public void applyParameters(Map<String, String> params) {
        // --- Apply Granularity ---
        int granularity = Integer.parseInt(params.get("Granularity"));
        AppConfig.TRAINING_WINDOW_SIZE = granularity;
        // Also save to properties so it's consistent if other parts of the app use it
        PersistenceUtility.setPropertyAndSave("TRAINING_WINDOW_SIZE", String.valueOf(granularity));

        // --- Apply Channels ---
        List<String> activeChannels = Arrays.asList(params.get("Channels").split(","));
        List<String> allPossibleChannels = Arrays.asList("Open", "High", "Low", "Close", "Volume", "Hour of Day", "Moving Average");

        for (String channelName : allPossibleChannels) {
            if (activeChannels.contains(channelName)) {
                PersistenceUtility.saveChannelProperty(channelName, "ON");
            } else {
                PersistenceUtility.saveChannelProperty(channelName, "OFF");
            }
        }
        
        // IMPORTANT: Refresh the active channel names list in AppConfig
        PersistenceUtility.loadChannels();
    }
}
