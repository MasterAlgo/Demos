package channels;

import globals.Globals;
import java.util.List;

public class HourOfDayChannel extends Channel {

    private String granularity;

    public HourOfDayChannel() {
        super("Hour of Day");
        refreshParameters(); // Initial load of parameters
    }

    @Override
    public void refreshParameters() {
        this.granularity = getConfigString("HourOfDay_granularity", "1 hour");
    }

    @Override
    public boolean populateWindow(DailyData currentDay, int minuteIndex, int windowSize, int[] targetArray) {
        // Alignment Check (Must match PriceChannel logic)
        if (minuteIndex + windowSize > currentDay.minutes.size()) return false;

        // Populate Target Array
        for (int i = 0; i < windowSize; i++) {
            int currentMinute = minuteIndex + i;

            // Check if the current minute data is missing
            if (currentDay.isMissing.get(currentMinute)) {
                targetArray[i] = Globals.MISSING_TOKEN;
                continue;
            }

            int minutesFromOpen = currentDay.minutes.get(currentMinute);
            
            int value;
            switch (granularity) {
                case "30 minutes":
                    value = minutesFromOpen / 30;
                    break;
                case "2 hours":
                    value = minutesFromOpen / 120;
                    break;
                case "1 hour":
                default:
                    value = minutesFromOpen / 60;
                    break;
            }
            targetArray[i] = value;
        }

        return true;
    }
}
