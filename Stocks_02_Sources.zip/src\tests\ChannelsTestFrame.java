package tests;

import javax.swing.*;
import java.awt.*;

public class ChannelsTestFrame extends JFrame {

    private JTextArea leftArea;   // Quantized Matrix
    private JTextArea rightArea;  // Raw File Lines
    private JTextArea bottomArea; // Verification Log
    
    private JButton nextButton;
    private JToggleButton runButton;
    private JButton fullCycleButton; // New Button
    private JCheckBox pauseOnMissing;
    
    private ChannelsTestController controller;

    public ChannelsTestFrame() {
        super("Channels Testing Grounds");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        initComponents();
        
        // Initialize Controller
        this.controller = new ChannelsTestController(this);
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // --- Top Split Pane (Left vs Right) ---
        leftArea = createTextArea("Quantized Matrix (System Output)");
        rightArea = createTextArea("Raw Data File (Disk Content)");
        
        JSplitPane topSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                new JScrollPane(leftArea), new JScrollPane(rightArea));
        topSplit.setResizeWeight(0.5);
        topSplit.setDividerLocation(0.5);

        // --- Bottom Area (Log) ---
        bottomArea = createTextArea("Verification Log (Comparison)");
        bottomArea.setForeground(Color.BLUE); // Distinct color for logs
        JScrollPane bottomScroll = new JScrollPane(bottomArea);
        bottomScroll.setPreferredSize(new Dimension(1200, 250));

        // --- Main Split Pane (Top vs Bottom) ---
        JSplitPane mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topSplit, bottomScroll);
        mainSplit.setResizeWeight(0.7);
        
        add(mainSplit, BorderLayout.CENTER);

        // --- Control Panel ---
        JPanel controlPanel = new JPanel();
        
        nextButton = new JButton("Next Step (1 Min)");
        nextButton.addActionListener(e -> controller.nextStep());
        
        runButton = new JToggleButton("Run / Stop");
        runButton.addActionListener(e -> {
            if (runButton.isSelected()) {
                controller.startAutoRun();
                nextButton.setEnabled(false);
                fullCycleButton.setEnabled(false);
            } else {
                controller.stopAutoRun();
                nextButton.setEnabled(true);
                fullCycleButton.setEnabled(true);
            }
        });
        
        fullCycleButton = new JButton("Full Cycle Test");
        fullCycleButton.addActionListener(e -> {
            new Thread(() -> {
                SwingUtilities.invokeLater(() -> {
                    fullCycleButton.setEnabled(false);
                    nextButton.setEnabled(false);
                    runButton.setEnabled(false);
                });
//                controller.runFullCycle();
                SwingUtilities.invokeLater(() -> {
                    fullCycleButton.setEnabled(true);
                    nextButton.setEnabled(true);
                    runButton.setEnabled(true);
                });
            }).start();
        });
        
        pauseOnMissing = new JCheckBox("Pause on [MISSING]");
        pauseOnMissing.setSelected(true);

        controlPanel.add(nextButton);
        controlPanel.add(runButton);
        controlPanel.add(fullCycleButton);
        controlPanel.add(pauseOnMissing);
        
        add(controlPanel, BorderLayout.SOUTH);
    }

    private JTextArea createTextArea(String title) {
        JTextArea area = new JTextArea();
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        area.setBorder(BorderFactory.createTitledBorder(title));
        return area;
    }

    // --- Accessors for Controller ---
    
    public void setLeftText(String text) {
        leftArea.setText(text);
    }

    public void setRightText(String text) {
        rightArea.setText(text);
    }

    public void setBottomText(String text) {
        bottomArea.setText(text);
    }
    
    public void appendLog(String text) {
        bottomArea.append(text + "\n");
        bottomArea.setCaretPosition(bottomArea.getDocument().getLength());
    }
    
    public void stopRun() {
        runButton.setSelected(false);
        nextButton.setEnabled(true);
        fullCycleButton.setEnabled(true);
    }
    
    public boolean isPauseOnMissing() {
        return pauseOnMissing.isSelected();
    }
}
