package utilities;

import channels.Channel;
import globals.AppConfig;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class PersistenceUtility {

    private static final String APP_PROPERTIES_FILE = "app.properties";
    private static final String CHANNELS_PROPERTIES_FILE = "channels.properties";
    private static final String PARAMETERS_PROPERTIES_FILE = "parameters.properties";

    public static void loadProperties() {
        loadPropertiesFromFile(APP_PROPERTIES_FILE, AppConfig.appProperties);
        AppConfig.updateStaticFields(); // Sync static fields after loading
        loadPropertiesFromFile(CHANNELS_PROPERTIES_FILE, AppConfig.channelProperties);
        loadParameters();
        loadChannels();
    }

    private static void loadPropertiesFromFile(String fileName, Properties props) {
        File file = new File(fileName);
        if (file.exists()) {
            try (InputStream input = new FileInputStream(file)) {
                props.load(input);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void loadParameters() {
        Properties params = new Properties();
        loadPropertiesFromFile(PARAMETERS_PROPERTIES_FILE, params);
        
        AppConfig.parametersMap.clear();
        for (String key : params.stringPropertyNames()) {
            String value = params.getProperty(key);
            if (value != null && !value.trim().isEmpty()) {
                String[] options = value.split(",");
                List<String> optionList = new ArrayList<>();
                for (String option : options) {
                    optionList.add(option.trim());
                }
                AppConfig.parametersMap.put(key, optionList);
            }
        }
    }

    public static void saveProperties() {
        savePropertiesToFile(APP_PROPERTIES_FILE, AppConfig.appProperties, "Application Settings");
        savePropertiesToFile(CHANNELS_PROPERTIES_FILE, AppConfig.channelProperties, "Channel Definitions");
    }

    private static void savePropertiesToFile(String fileName, Properties props, String comments) {
        try (OutputStream output = new FileOutputStream(fileName)) {
            props.store(output, comments);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void save(String key, String value) {
        AppConfig.appProperties.setProperty(key, value);
    }

    /**
     * Sets a property and immediately saves it to disk.
     */
    public static void setPropertyAndSave(String key, String value) {
        AppConfig.appProperties.setProperty(key, value);
        saveProperties();
    }
    
    public static void saveChannelProperty(String key, String value) {
        // 1. Update the property in memory
        AppConfig.channelProperties.setProperty(key, value);
        
        // 2. Save all channel properties to the file
        savePropertiesToFile(CHANNELS_PROPERTIES_FILE, AppConfig.channelProperties, "Channel Definitions");
        
        // 3. Notify all active channels to refresh their parameters
        for (Channel channel : AppConfig.activeChannels.values()) {
            channel.refreshParameters();
        }
    }

    public static String load(String key) {
        return AppConfig.appProperties.getProperty(key, "");
    }

    public static void loadChannels() {
        AppConfig.activeChannelNames.clear();
        List<String> sortedNames = new ArrayList<>(AppConfig.channelProperties.stringPropertyNames());
        java.util.Collections.sort(sortedNames);

        for (String channelName : sortedNames) {
            // Only consider properties that are simple ON/OFF toggles as active channel names
            // Parameter settings (e.g., "Volume_gradingStrategy") are stored in the same file but shouldn't be treated as channel names here
            String value = AppConfig.channelProperties.getProperty(channelName);
            if ("ON".equalsIgnoreCase(value)) {
                AppConfig.activeChannelNames.add(channelName);
            }
        }
    }
}
