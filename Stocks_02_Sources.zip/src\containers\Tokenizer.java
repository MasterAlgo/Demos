package containers;

import globals.AppConfig;
import globals.Globals;

public class Tokenizer {

    // Reusable buffers
    private int[] columnUidOptions; // Stores UIDs for [column] (Full variation only)
    private int[] currentSequence;
    private int[] maskedColumnBuffer;

    private boolean isInitialized = false;
    private int numRows; // N (Channels)
    private int numCols; // K (Time)

    /**
     * Initializes the Tokenizer_retired with fixed dimensions.
     */
    public void initialize() {
        // Always re-initialize to pick up changes in AppConfig (e.g. from Optimizer)
        this.numRows = AppConfig.activeChannels.size();
        this.numCols = AppConfig.TRAINING_WINDOW_SIZE;

        // We only need to store 1 variation per column: The "Full" UID.
        // The "Empty" variation is always represented by UID 0.
        this.columnUidOptions = new int[numCols];

        this.currentSequence = new int[numCols];
        this.maskedColumnBuffer = new int[numRows];

        this.isInitialized = true;
    }

    /**
     * Generates patterns using a "Horizontal-First" or "Shared Horizontal Mask" strategy.
     * This avoids the combinatorial explosion of the previous tokenizer.
     *
     * @param matrix The input matrix [Rows/Channels][Columns/Time]
     * @param future The future value vector. Can be null if not training.
     */
    public void tokenize(int[][] matrix, int[] future) {
        if (!isInitialized) {
            initialize();
        }

        // Safety check
        if (matrix == null || matrix.length != numRows || matrix[0].length != numCols) {
            System.err.println("Tokenizer Error: Matrix dimensions mismatch. Expected [" + numRows + "][" + numCols + "] but got [" + (matrix != null ? matrix.length : "null") + "][" + (matrix != null && matrix.length > 0 ? matrix[0].length : "null") + "]");
            // Re-initialize and try again? No, that might mask a deeper issue in ChannelManager.
            // But for the optimizer, we expect dimensions to change.
            // If initialize() was called correctly by DataController, numRows/numCols should match AppConfig.
            // If matrix dimensions don't match numRows/numCols, then ChannelManager produced a matrix 
            // that doesn't match AppConfig.
            return;
        }

//         //DEBUG_PRINT START
//         System.out.println("DEBUG: Tokenizer.tokenize matrix:");
//         for (int i = 0; i < numRows; i++) {
//             for (int j = 0; j < numCols; j++) {
//                 int val = matrix[i][j];
//                 if (val == Globals.MISSING_TOKEN) {
//                     System.out.print("** ");
//                 } else {
//                     System.out.printf("%2d ", val);
//                 }
//             }
//             System.out.println();
//         }
//         //DEBUG_PRINT END

        // 1. Pre-compute the "Full" UID for each column of the current matrix.
        for (int col = 0; col < numCols; col++) {
            columnUidOptions[col] = generateColumnVariation(matrix, col);
        }

        // 2. Iterate through all possible HORIZONTAL masks.
        long numHorizontalMasks = 1L << numCols;

        for (long mask = 0; mask < numHorizontalMasks; mask++) {
            // Check if the number of active time steps meets the minimum requirement.
            int actualTokens = Long.bitCount(mask);
            if (actualTokens < AppConfig.MIN_ACTUAL_TOKENS) {
                continue;
            }

            // 3. Construct the sequence based on the current horizontal mask.
            for (int k = 0; k < numCols; k++) {
                // DEBUG_PRINT START
                // System.out.printf("DEBUG: columnUidOptions[%d]: %d\n", k, columnUidOptions[k]);
                // DEBUG_PRINT END
                
                // Check if the k-th bit is set in the mask.
                if ((mask & (1L << k)) != 0) {
                    // Active time step: Use the "Full" token.
                    currentSequence[k] = columnUidOptions[k];
                } else {
                    // Skipped time step: Use the "Empty" token (0).
                    currentSequence[k] = 0;
                }
            }

            // DEBUG_PRINT START
            // System.out.print("DEBUG: Tokenizer.tokenize currentSequence: ");
            // for (int val : currentSequence) {
            //     System.out.printf("%4d ", val);
            // }
            // System.out.println();
            // DEBUG_PRINT END

            // 4. Process the generated sequence.
            // Predict / Infer from existing history
            int[] history = Globals.patternEngine.get(currentSequence);
            if (history != null) {
                Globals.inferenceEngine.submit(history, actualTokens, currentSequence); // predict
            }

            // Train with the new observation
            if (future != null) {
                Globals.patternEngine.update(currentSequence, future); // train
            }
        }
    }

    /**
     * Generates only the "Full" variation of a column and returns its UID.
     */
    private int generateColumnVariation(int[][] matrix, int colIndex) {
        // Variation 1: Full (All channels present)
        for (int bit = 0; bit < numRows; bit++) {
            maskedColumnBuffer[bit] = matrix[bit][colIndex];
        }
        return Globals.tokenDictionary.getOrAdd(maskedColumnBuffer);
    }
}
