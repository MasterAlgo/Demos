package utilities;

import channels.DailyData;
import globals.Globals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class DataLoader {

    public static void load(String cleanedFilePath) throws IOException {
        if (Globals.allData == null) {
            Globals.allData = new ArrayList<>();
        } else {
            Globals.allData.clear();
        }

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

        DailyData currentDailyData = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(cleanedFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                // parts[0] = Date
                // parts[1] = Time
                // parts[2] = Open
                // parts[3] = High
                // parts[4] = Low
                // parts[5] = Close
                // parts[6] = Volume
                // parts[7] = isMissing (0 or 1)

                LocalDate date = LocalDate.parse(parts[0], dateFormatter);
                
                // Parse time to minutes from open (9:30)
                LocalTime time = LocalTime.parse(parts[1], timeFormatter);
                int minutesFromOpen = (time.getHour() * 60 + time.getMinute()) - (9 * 60 + 30);

                if (currentDailyData == null || !currentDailyData.date.equals(date)) {
                    currentDailyData = new DailyData(date);
                    Globals.allData.add(currentDailyData);
                }

                currentDailyData.minutes.add(minutesFromOpen);
                currentDailyData.openPrices.add(Float.parseFloat(parts[2]));
                currentDailyData.highPrices.add(Float.parseFloat(parts[3]));
                currentDailyData.lowPrices.add(Float.parseFloat(parts[4]));
                currentDailyData.closePrices.add(Float.parseFloat(parts[5]));
                currentDailyData.volumes.add(Integer.parseInt(parts[6]));
                
                // Parse isMissing flag
                boolean isMissing = false;
                if (parts.length > 7) {
                    isMissing = "1".equals(parts[7]);
                }
                currentDailyData.isMissing.add(isMissing);
            }
        }

        // Remove any days that might be empty (shouldn't happen with new CleanData logic)
        Globals.allData.removeIf(d -> d.openPrices.isEmpty());
    }
}
