package ui;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DistributionDetailFrame extends JFrame {

    private final DistributionGraphPanel graphPanel;
    private final JSpinner startIndexSpinner;
    private final JSpinner endIndexSpinner;
    private final JCheckBox logScaleCheckBox;
    private final JCheckBox showValuesCheckBox;

    public DistributionDetailFrame(List<int[]> history) {
        setTitle("Distribution Details");
        setSize(800, 600);
        setLocationRelativeTo(null); // Center on screen
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Graph Panel
        graphPanel = new DistributionGraphPanel();
        // Pre-load history
        for (int[] dist : history) {
            graphPanel.addDistribution(dist);
        }
        // Set initial settings
        graphPanel.setRange(2, 99);
        graphPanel.setLogScale(true);
        
        add(graphPanel, BorderLayout.CENTER);

        // Controls Panel
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        controlsPanel.add(new JLabel("Start Index:"));
        startIndexSpinner = new JSpinner(new SpinnerNumberModel(2, 1, 99, 1));
        startIndexSpinner.addChangeListener(e -> updateGraphSettings());
        controlsPanel.add(startIndexSpinner);

        controlsPanel.add(new JLabel("End Index:"));
        endIndexSpinner = new JSpinner(new SpinnerNumberModel(99, 2, 99, 1));
        endIndexSpinner.addChangeListener(e -> updateGraphSettings());
        controlsPanel.add(endIndexSpinner);

        logScaleCheckBox = new JCheckBox("Log Scale", true);
        logScaleCheckBox.addActionListener(e -> updateGraphSettings());
        controlsPanel.add(logScaleCheckBox);
        
        showValuesCheckBox = new JCheckBox("Show Values", false);
        showValuesCheckBox.addActionListener(e -> updateGraphSettings());
        controlsPanel.add(showValuesCheckBox);

        add(controlsPanel, BorderLayout.SOUTH);
    }

    public void updateHistory(List<int[]> history) {
        // Clear and reload to ensure sync
        graphPanel.clearHistory();
        for (int[] dist : history) {
            graphPanel.addDistribution(dist);
        }
    }

    private void updateGraphSettings() {
        int start = (Integer) startIndexSpinner.getValue();
        int end = (Integer) endIndexSpinner.getValue();
        boolean logScale = logScaleCheckBox.isSelected();
        boolean showValues = showValuesCheckBox.isSelected();

        if (start >= end) {
            start = end - 1;
            startIndexSpinner.setValue(start);
        }

        graphPanel.setRange(start, end);
        graphPanel.setLogScale(logScale);
        graphPanel.setShowValues(showValues);
    }
}
