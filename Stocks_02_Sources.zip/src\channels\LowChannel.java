package channels;

public class LowChannel extends PriceChannel {
    public LowChannel() {
        super("Low");
    }

    @Override
    protected float getPrice(DailyData day, int index) {
        return day.lowPrices.get(index);
    }
}
