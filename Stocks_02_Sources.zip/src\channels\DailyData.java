package channels;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DailyData {
    public LocalDate date;
    public List<Integer> minutes = new ArrayList<>(); // Minutes from open (e.g., 0 = 9:30 AM)
    public List<Float> openPrices = new ArrayList<>();
    public List<Float> highPrices = new ArrayList<>();
    public List<Float> lowPrices = new ArrayList<>();
    public List<Float> closePrices = new ArrayList<>();
    public List<Integer> volumes = new ArrayList<>();
    
    // Marker for missing/fake data points
    public List<Boolean> isMissing = new ArrayList<>();

    public DailyData(LocalDate date) {
        this.date = date;
    }
}
