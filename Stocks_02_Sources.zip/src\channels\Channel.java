package channels;

import globals.AppConfig;

public abstract class Channel {
    protected String name;

    public Channel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * Populates the provided target array with quantized data for a specific window.
     * This is the "on-the-fly" processing method, optimized for zero allocation.
     *
     * @param currentDay The DailyData object for the current day.
     * @param minuteIndex The index of the current minute within the current day.
     * @param windowSize The desired size of the output window.
     * @param targetArray The array to populate. Must be of size 'windowSize'.
     * @return true if the window was successfully populated, false if invalid (e.g., out of bounds).
     */
    public abstract boolean populateWindow(DailyData currentDay, int minuteIndex, int windowSize, int[] targetArray);

    /**
     * Refreshes the channel's parameters from the global configuration.
     * Subclasses should override this to update their local state when parameters change.
     */
    public void refreshParameters() {
        // Default implementation does nothing.
    }

    // --- Configuration Helpers ---

    protected int getConfigInt(String key, int defaultValue) {
        String val = AppConfig.channelProperties.getProperty(name + "_" + key);
        if (val == null) {
            val = AppConfig.channelProperties.getProperty(key);
        }
        
        if (val == null) return defaultValue;
        
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    protected String getConfigString(String key, String defaultValue) {
        String val = AppConfig.channelProperties.getProperty(name + "_" + key);
        if (val == null) {
            val = AppConfig.channelProperties.getProperty(key);
        }
        return val == null ? defaultValue : val;
    }
}
