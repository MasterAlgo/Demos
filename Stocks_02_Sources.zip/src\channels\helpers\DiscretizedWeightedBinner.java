package channels.helpers;

import java.util.*;

public class DiscretizedWeightedBinner {
    private final int k;                 // number of bins
    private final int step;              // quantization step, e.g. 1000
    private final TreeMap<Integer, Long> wByBucket = new TreeMap<>();
    private long totalW = 0;

    // boundaries stored as bucket keys, length k-1
    private int[] boundaries;

    public DiscretizedWeightedBinner(int k, int step) {
        if (k < 2) throw new IllegalArgumentException("k>=2");
        if (step <= 0) throw new IllegalArgumentException("step>0");
        this.k = k;
        this.step = step;
        this.boundaries = new int[k - 1];
    }

    /** Add one observation. weightMode: "volume" => w=v, "count" => w=1 */
    public void add(long volume, boolean weightByVolume) {
        int bucket = (int)(volume / step);
        long w = weightByVolume ? volume : 1L;

        wByBucket.merge(bucket, w, Long::sum);
        totalW += w;

        recomputeBoundaries();
    }

    private void recomputeBoundaries() {
        if (totalW <= 0 || wByBucket.isEmpty()) return;

        long stepW = totalW / k;
        if (stepW <= 0) stepW = 1; // tiny streams safety

        int j = 1;                 // boundary index is j-1
        long target = stepW;       // j*stepW
        long cum = 0;

        for (Map.Entry<Integer, Long> e : wByBucket.entrySet()) {
            cum += e.getValue();
            while (j < k && cum >= target) {
                boundaries[j - 1] = e.getKey();
                j++;
                target = (long)j * stepW;
            }
            if (j >= k) break;
        }

        // ensure nondecreasing (duplicates possible)
        for (int i = 1; i < boundaries.length; i++) {
            if (boundaries[i] < boundaries[i - 1]) boundaries[i] = boundaries[i - 1];
        }
    }

    /** Return bin index [0..k-1] for a volume. */
    public int binIndex(long volume) {
        int b = (int)(volume / step);
        int idx = Arrays.binarySearch(boundaries, b);
        if (idx >= 0) return Math.min(idx + 1, k - 1);
        int ip = -idx - 1;
        return Math.min(Math.max(ip, 0), k - 1);
    }

    /** Boundaries in raw volume units (multiples of step). */
    public long[] getBoundaryVolumes() {
        long[] out = new long[boundaries.length];
        for (int i = 0; i < boundaries.length; i++) out[i] = (long)boundaries[i] * step;
        return out;
    }
}
